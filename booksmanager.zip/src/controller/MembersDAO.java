package controller;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;

import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import model.MembersVO;

public class MembersDAO {

	// �ű� ȸ�� ���
	public MembersVO getMembersregiste(MembersVO mVo) throws Exception {
		// ������ ó���� ���� SQL��
		String dml = "insert into members (mnum, name,birth, phone,gender,  email,  address, registerDate, note) values"
				+ "(members_seq.nextval, ?, ?, ?, ?, ?, ?, sysdate, ?)";
		Connection con = null;
		PreparedStatement pstmt = null;
		MembersVO retval = null;

		try {
			// DBUtil �̶�� Ŭ������ getConnection() �޼ҵ�� ������ ���̽��� ����
			con = DBUtil.getConnection();

			// �Է¹��� ȸ�� ������ ó���ϱ� ���Ͽ� SQL�������
			pstmt = con.prepareStatement(dml);
			pstmt.setString(1, mVo.getName());
			pstmt.setInt(2, mVo.getBirth());
			pstmt.setString(3, mVo.getPhone());
			pstmt.setString(4, mVo.getGender());
			pstmt.setString(5, mVo.getEmail());
			pstmt.setString(6, mVo.getAddress());
			pstmt.setString(7, mVo.getNote());

			// SQL���� ���� �� ó�� ����� ����
			int i = pstmt.executeUpdate();
			retval = new MembersVO();
		} catch (SQLException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				// �����ͺ��̽����� ���ῡ ���Ǿ��� ������Ʈ�� ����
				if (pstmt != null)
					pstmt.close();
				if (con != null)
					con.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return retval;
	}

	// ȸ���� name�� �Է¹޾� ���� ��ȸ
	public MembersVO getMembersCheck(String name) throws Exception {
		String dml = "select * from Members where name = ?";

		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		MembersVO retval = null;
		try {
			con = DBUtil.getConnection();
			pstmt = con.prepareStatement(dml);
			pstmt.setString(1, name);
			rs = pstmt.executeQuery();
			if (rs.next()) {
				retval = new MembersVO(rs.getInt(1), rs.getString(2), rs.getInt(3), rs.getString(4), rs.getString(5),
						rs.getString(6), rs.getString(7), rs.getString(8), rs.getString(9));
			}
		} catch (SQLException se) {
			System.out.println(se);
		} catch (Exception e) {
			System.out.println(e);
		} finally {
			try {
				if (rs != null)
					rs.close();
				if (pstmt != null)
					pstmt.close();
				if (con != null)
					con.close();

			} catch (SQLException se) {

			}
		}
		return retval;
	}

	// ȸ���� num�� �Է¹޾� ���� ��ȸ
	public MembersVO getMembersCheck1(String num) throws Exception {
		String dml = "select * from Members where mnum = ?";

		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		MembersVO retval = null;
		try {
			con = DBUtil.getConnection();
			pstmt = con.prepareStatement(dml);
			pstmt.setString(1, num);
			rs = pstmt.executeQuery();
			if (rs.next()) {
				retval = new MembersVO(rs.getInt(1), rs.getString(2), rs.getInt(3), rs.getString(4), rs.getString(5),
						rs.getString(6), rs.getString(7), rs.getString(8), rs.getString(9));

			}
		} catch (SQLException se) {
			System.out.println(se);
		} catch (Exception e) {
			System.out.println(e);
		} finally {
			try {
				if (rs != null)
					rs.close();
				if (pstmt != null)
					pstmt.close();
				if (con != null)
					con.close();

			} catch (SQLException se) {

			}
		}
		return retval;
	}

	// ȸ������
	public void getMembersDelete(int num) {
		StringBuffer sql = new StringBuffer();
		sql.append("delete from Members where mnum = ?");
		Connection con = null;
		PreparedStatement pstmt = null;
		try {
			con = DBUtil.getConnection();
			pstmt = con.prepareStatement(sql.toString());
			pstmt.setInt(1, num);

			int i = pstmt.executeUpdate();

			if (i == 1) {
				Alert alert = new Alert(AlertType.INFORMATION);
				alert.setTitle("ȸ�� ����");
				alert.setHeaderText("ȸ�� ���� �Ϸ�.");
				alert.setContentText("ȸ�� ���� ����!!!");
				alert.showAndWait();
			} else {
				Alert alert = new Alert(AlertType.INFORMATION);
				alert.setTitle("ȸ�� ����");
				alert.setHeaderText("ȸ�� ���� ����.");
				alert.setContentText("ȸ�� ���� ����!!!");
				alert.showAndWait();
			}

		} catch (Exception ex) {
			System.out.println(ex);
		} finally {
			try {
				if (pstmt != null)
					pstmt.close();
				if (con != null)
					con.close();
			} catch (Exception e) {
				System.out.println(e);
			}
		}

	}

	// ȸ�� ��ü ����Ʈ
	public ArrayList<MembersVO> getMembersTotal() {
		ArrayList<MembersVO> list = new ArrayList<MembersVO>();
		String tml = "select * from Members";

		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		MembersVO mVo = null;

		try {
			con = DBUtil.getConnection();
			pstmt = con.prepareStatement(tml);
			rs = pstmt.executeQuery();
			while (rs.next()) {

				mVo = new MembersVO(rs.getInt(1), rs.getString(2), rs.getInt(3), rs.getString(4), rs.getString(5),
						rs.getString(6), rs.getString(7), rs.getDate(8) + "", rs.getString(9));
				list.add(mVo);

			}
		} catch (SQLException se) {
			System.out.println(se);
		} catch (Exception e) {
			System.out.println(e);
		} finally {
			try {
				if (rs != null)
					rs.close();
				if (pstmt != null)
					pstmt.close();
				if (con != null)
					con.close();
			} catch (SQLException se) {

			}
		}
		return list;
	}

	// �����ͺ��̽����� ȸ�� ���̺��� �÷��� ����
	public ArrayList<String> getColumnName() {
		ArrayList<String> columnName = new ArrayList<String>();

		String sql = "select * from Members";
		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		// ResultSetMetaData ��ü ���� ����
		ResultSetMetaData rsmd = null;

		try {
			con = DBUtil.getConnection();
			pstmt = con.prepareStatement(sql);
			rs = pstmt.executeQuery();
			rsmd = rs.getMetaData();
			int cols = rsmd.getColumnCount();
			for (int i = 1; i <= cols; i++) {
				columnName.add(rsmd.getColumnName(i));
			}

		} catch (SQLException se) {
			System.out.println(se);
		} catch (Exception e) {
			System.out.println(e);
		} finally {
			try {
				if (rs != null)
					rs.close();
				if (pstmt != null)
					pstmt.close();
				if (con != null)
					con.close();
			} catch (SQLException se) {

			}
		}
		return columnName;
	}

	// ������ ȸ�� ����
	public MembersVO getMembersUpdate(MembersVO mVo, int num) throws Exception {
		// ������ ó���� ���� SQL��
		String dml = "update Members set "
				+ "mnum=?, name=?, birth=?,phone=?,gender=?,  email=?, address=?,  note=? where mnum=?  ";
		Connection con = null;
		PreparedStatement pstmt = null;
		MembersVO retval = null;

		try {
			// DBUtil�̶�� Ŭ������ getConnection()�޼ҵ�� �����ͺ��̽��� ����
			con = DBUtil.getConnection();
			// ������ ȸ�� ������ �����ϱ� ���Ͽ� SQL������ ����
			pstmt = con.prepareStatement(dml);
			pstmt.setInt(1, mVo.getMnum());
			pstmt.setString(2, mVo.getName());
			pstmt.setInt(3, mVo.getBirth());
			pstmt.setString(4, mVo.getPhone());
			pstmt.setString(5, mVo.getGender());
			pstmt.setString(6, mVo.getEmail());
			pstmt.setString(7, mVo.getAddress());
			pstmt.setString(8, mVo.getNote());
			pstmt.setInt(9, mVo.getMnum());

			// SQL���� ������ �� ó�� ����� ����
			int i = pstmt.executeUpdate();

			if (i == 1) {
				Alert alert = new Alert(AlertType.INFORMATION);
				alert.setTitle("���� ���");
				alert.setContentText("����!!");
				alert.showAndWait();
				retval = new MembersVO();

			} else {
				Alert alert = new Alert(AlertType.INFORMATION);
				alert.setTitle("���� ���");
				alert.setContentText("����!!");
				alert.showAndWait();
			}
		} catch (SQLException e) {
			System.out.println(e.toString());
		} catch (Exception e) {
			System.out.println();
		} finally {
			try {
				// �����ͺ��̽����� ���ῡ ���Ǿ��� ������Ʈ�� ����
				if (pstmt != null)
					pstmt.close();
				if (con != null)
					con.close();
			} catch (SQLException e) {

			}
		}
		return retval;

	}

	// ȸ���� �̸��� ��ȸ
	public String getMembersEmail(int num) throws Exception {
		String dml = "select email from Members where mnum = ?";
		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String result = null;
		try {
			con = DBUtil.getConnection();
			pstmt = con.prepareStatement(dml);
			pstmt.setInt(1, num);
			rs = pstmt.executeQuery();
			if (rs.next()) {
				result = rs.getString(1);
			}
			System.out.println("Email: " + result);
		} catch (SQLException se) {
			System.out.println(se);
		} catch (Exception e) {
			System.out.println(e);
		} finally {
			try {
				if (rs != null)
					rs.close();
				if (pstmt != null)
					pstmt.close();
				if (con != null)
					con.close();

			} catch (SQLException se) {

			}
		}
		return result;
	}

	// ȸ���� �̸� ��ȸ
	public String getMembersName(int num) throws Exception {
		String dml = "select name from Members where mnum = ?";
		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String result = null;
		try {
			con = DBUtil.getConnection();
			pstmt = con.prepareStatement(dml);
			pstmt.setInt(1, num);
			rs = pstmt.executeQuery();
			if (rs.next()) {
				result = rs.getString(1);
			}
			System.out.print(result + " ");
		} catch (SQLException se) {
			System.out.println(se);
		} catch (Exception e) {
			System.out.println(e);
		} finally {
			try {
				if (rs != null)
					rs.close();
				if (pstmt != null)
					pstmt.close();
				if (con != null)
					con.close();

			} catch (SQLException se) {

			}
		}
		return result;
	}

}
