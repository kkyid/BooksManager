package controller;

import java.io.IOException;
import java.net.URL;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.ResourceBundle;

import org.apache.commons.mail.MultiPartEmail;
import org.apache.log4j.Logger;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.input.MouseEvent;
import javafx.stage.Modality;
import javafx.stage.Stage;
import javafx.stage.StageStyle;
import model.BooksVO;
import model.InfoVO;
import model.MembersVO;

public class BooksController implements Initializable {
	private static Logger logger = Logger.getLogger(BooksController.class);
	@FXML
	private TextField txtB_num;
	@FXML
	private TextField txtB_name;
	@FXML
	private TextField txtB_authorMatter;
	@FXML
	private TextField txtB_publicationMatter;
	@FXML
	private TextField txtB_dataType;
	@FXML
	private TextField txtB_group;
	@FXML
	private TextField txtB_ISBN;
	@FXML
	private TextField txtB_registerNum;
	@FXML
	private TextField txtB_address;
	@FXML
	private TextField txtB_loanSituation;
	@FXML
	private TextField txtB_name1;
	@FXML
	private TextField txtB_num1;

	@FXML
	private Button btnB_reset;
	@FXML
	private Button btnB_search;
	@FXML
	private Button btnB_edit;
	@FXML
	private Button btnB_delete;
	@FXML
	private Button btnB_reservation;
	@FXML
	private Button btnB_ok;
	@FXML
	private Button btnR_search;

	@FXML
	private TextField txtMnum;
	@FXML
	private TextField txtName;
	@FXML
	private TextField txtGender;
	@FXML
	private TextField txtBirth;
	@FXML
	private TextField txtPhone;
	@FXML
	private TextField txtAddress;
	@FXML
	private TextField txtEmail;
	@FXML
	private TextField txtRegisterDate;
	@FXML
	private TextField txtNote;
	@FXML
	private TextField txtNum1;
	@FXML
	private TextField txtName1;

	@FXML
	private Button btnReset;
	@FXML
	private Button btnSearch;
	@FXML
	private Button btnEdit;
	@FXML
	private Button btnDelete;
	@FXML
	private Button btnInquiry;
	@FXML
	private Button btnOk;

	@FXML
	private TextField txtB_searchName;
	@FXML
	private TextField txtB_searchNum;
	@FXML
	private Button btnL_search;
	@FXML
	private Button btnReservation;
	@FXML
	private Button btnL_loan;
	@FXML
	private Button btnL_return;
	@FXML
	private Button btnL_reset;

	@FXML
	private Button btnReturnOk;
	@FXML
	private Button btnReturnCancel;

	@FXML
	private TableView<BooksVO> tableView = new TableView<>();
	@FXML
	private TableView<BooksVO> tableView2 = new TableView<>();
	@FXML
	private TableView<BooksVO> tableView3;

	@FXML
	private TableView<MembersVO> tableView1 = new TableView<>();
	@FXML
	private TableView<MembersVO> tableViewR = new TableView<>();
	@FXML
	private TableView<InfoVO> tableViewI = new TableView<>();

	@FXML

	ObservableList<BooksVO> data = FXCollections.observableArrayList();
	ObservableList<BooksVO> data2 = FXCollections.observableArrayList();
	ObservableList<BooksVO> dataloan = FXCollections.observableArrayList();

	ObservableList<MembersVO> data1 = FXCollections.observableArrayList();
	ObservableList<MembersVO> data3 = FXCollections.observableArrayList();

	ObservableList<InfoVO> dataI = FXCollections.observableArrayList();

	BooksVO books = new BooksVO();
	MembersVO members = new MembersVO();
	MembersVO mVo = new MembersVO();
	MembersVO mVo1 = new MembersVO();
	MembersDAO mDao = new MembersDAO();

	ObservableList<BooksVO> selectBook; // ���̺��� ���������� ����
	ObservableList<MembersVO> selectMember; // ���̺��� ���������� ����

	boolean editDelete = false; // Ȯ�ι�ư���� ����

	int selectedIndex; // ���̺����� ������ �������� �ε��� ����

	public void initialize(URL arg0, ResourceBundle arg1) {
		txtRegisterDate.setDisable(true);
		btnL_loan.setDisable(true);
		txtB_num.setDisable(true);
		txtB_loanSituation.setDisable(true);
		txtMnum.setDisable(true);
		btnB_edit.setDisable(true);
		btnB_reservation.setDisable(true);
		btnB_delete.setDisable(true);
		btnEdit.setDisable(true);
		btnDelete.setDisable(true);
		btnInquiry.setDisable(true);
		btnL_return.setDisable(true);
		// ���̺� �׸���

		TableColumn colB_num = new TableColumn("NO.");
		colB_num.setMaxWidth(40);
		colB_num.setStyle("-fx-alignment: CENTER ");
		colB_num.setCellValueFactory(new PropertyValueFactory<>("b_num"));

		TableColumn colB_name = new TableColumn("������");
		colB_name.setMinWidth(110);
		colB_name.setStyle("-fx-alignment: CENTER");
		colB_name.setCellValueFactory(new PropertyValueFactory<>("b_name"));

		TableColumn colB_authorMatter = new TableColumn("���ڻ���");
		colB_authorMatter.setMinWidth(155);
		colB_authorMatter.setStyle("-fx-alignment:CENTER");
		colB_authorMatter.setCellValueFactory(new PropertyValueFactory<>("b_authormatter"));

		TableColumn colB_publicationMatter = new TableColumn("�������");
		colB_publicationMatter.setMinWidth(155);
		colB_publicationMatter.setStyle("-fx-alignment: CENTER");
		colB_publicationMatter.setCellValueFactory(new PropertyValueFactory<>("b_publicationmatter"));

		TableColumn colB_group = new TableColumn("�з�");
		colB_group.setMinWidth(100);
		colB_group.setStyle("-fx-alignment: CENTER");
		colB_group.setCellValueFactory(new PropertyValueFactory<>("b_group"));

		TableColumn colB_registerNum = new TableColumn("��Ϲ�ȣ");
		colB_registerNum.setMinWidth(100);
		colB_registerNum.setStyle("-fx-alignment: CENTER");
		colB_registerNum.setCellValueFactory(new PropertyValueFactory<>("b_registernum"));

		TableColumn colB_ISBN = new TableColumn("ISBN");
		colB_ISBN.setMinWidth(130);
		colB_ISBN.setStyle("-fx-alignment: CENTER");
		colB_ISBN.setCellValueFactory(new PropertyValueFactory<>("b_isbn"));

		TableColumn colB_dataType = new TableColumn("�ڷ�����");
		colB_dataType.setMinWidth(100);
		colB_dataType.setStyle("-fx-alignment: CENTER");
		colB_dataType.setCellValueFactory(new PropertyValueFactory<>("b_datatype"));

		TableColumn colB_loanSituation = new TableColumn("�������");
		colB_loanSituation.setMinWidth(60);
		colB_loanSituation.setStyle("-fx-alignment: CENTER");
		colB_loanSituation.setCellValueFactory(new PropertyValueFactory<>("b_loansituation"));

		TableColumn colB_num1 = new TableColumn("NO.");
		colB_num1.setMaxWidth(40);
		colB_num1.setStyle("-fx-alignment: CENTER ");
		colB_num1.setCellValueFactory(new PropertyValueFactory<>("b_num"));

		TableColumn colB_name1 = new TableColumn("������");
		colB_name1.setMinWidth(110);
		colB_name1.setStyle("-fx-alignment: CENTER");
		colB_name1.setCellValueFactory(new PropertyValueFactory<>("b_name"));

		TableColumn colB_authorMatter1 = new TableColumn("���ڻ���");
		colB_authorMatter1.setMinWidth(155);
		colB_authorMatter1.setStyle("-fx-alignment:CENTER");
		colB_authorMatter1.setCellValueFactory(new PropertyValueFactory<>("b_authormatter"));

		TableColumn colB_publicationMatter1 = new TableColumn("�������");
		colB_publicationMatter1.setMinWidth(155);
		colB_publicationMatter1.setStyle("-fx-alignment: CENTER");
		colB_publicationMatter1.setCellValueFactory(new PropertyValueFactory<>("b_publicationmatter"));

		TableColumn colB_group1 = new TableColumn("�з�");
		colB_group1.setMinWidth(100);
		colB_group1.setStyle("-fx-alignment: CENTER");
		colB_group1.setCellValueFactory(new PropertyValueFactory<>("b_group"));

		TableColumn colB_registerNum1 = new TableColumn("��Ϲ�ȣ");
		colB_registerNum1.setMinWidth(100);
		colB_registerNum1.setStyle("-fx-alignment: CENTER");
		colB_registerNum1.setCellValueFactory(new PropertyValueFactory<>("b_registernum"));

		TableColumn colB_ISBN1 = new TableColumn("ISBN");
		colB_ISBN1.setMinWidth(130);
		colB_ISBN1.setStyle("-fx-alignment: CENTER");
		colB_ISBN1.setCellValueFactory(new PropertyValueFactory<>("b_isbn"));

		TableColumn colB_dataType1 = new TableColumn("�ڷ�����");
		colB_dataType1.setMinWidth(100);
		colB_dataType1.setStyle("-fx-alignment: CENTER");
		colB_dataType1.setCellValueFactory(new PropertyValueFactory<>("b_datatype"));

		TableColumn colB_loanSituation1 = new TableColumn("�������");
		colB_loanSituation1.setMinWidth(60);
		colB_loanSituation1.setStyle("-fx-alignment: CENTER");
		colB_loanSituation1.setCellValueFactory(new PropertyValueFactory<>("b_loansituation"));

		TableColumn colB_num2 = new TableColumn("NO.");
		colB_num2.setMaxWidth(40);
		colB_num2.setStyle("-fx-alignment: CENTER ");
		colB_num2.setCellValueFactory(new PropertyValueFactory<>("b_num"));

		TableColumn colB_name2 = new TableColumn("������");
		colB_name2.setMinWidth(110);
		colB_name2.setStyle("-fx-alignment: CENTER");
		colB_name2.setCellValueFactory(new PropertyValueFactory<>("b_name"));

		TableColumn colB_authorMatter2 = new TableColumn("���ڻ���");
		colB_authorMatter2.setMinWidth(155);
		colB_authorMatter2.setStyle("-fx-alignment:CENTER");
		colB_authorMatter2.setCellValueFactory(new PropertyValueFactory<>("b_authormatter"));

		TableColumn colB_publicationMatter2 = new TableColumn("�������");
		colB_publicationMatter2.setMinWidth(155);
		colB_publicationMatter2.setStyle("-fx-alignment: CENTER");
		colB_publicationMatter2.setCellValueFactory(new PropertyValueFactory<>("b_publicationmatter"));

		TableColumn colB_group2 = new TableColumn("�з�");
		colB_group2.setMinWidth(100);
		colB_group2.setStyle("-fx-alignment: CENTER");
		colB_group2.setCellValueFactory(new PropertyValueFactory<>("b_group"));

		TableColumn colB_registerNum2 = new TableColumn("��Ϲ�ȣ");
		colB_registerNum2.setMinWidth(100);
		colB_registerNum2.setStyle("-fx-alignment: CENTER");
		colB_registerNum2.setCellValueFactory(new PropertyValueFactory<>("b_registernum"));

		TableColumn colB_ISBN2 = new TableColumn("ISBN");
		colB_ISBN2.setMinWidth(130);
		colB_ISBN2.setStyle("-fx-alignment: CENTER");
		colB_ISBN2.setCellValueFactory(new PropertyValueFactory<>("b_isbn"));

		TableColumn colB_dataType2 = new TableColumn("�ڷ�����");
		colB_dataType2.setMinWidth(100);
		colB_dataType2.setStyle("-fx-alignment: CENTER");
		colB_dataType2.setCellValueFactory(new PropertyValueFactory<>("b_datatype"));

		TableColumn colB_loanSituation2 = new TableColumn("�������");
		colB_loanSituation2.setMinWidth(60);
		colB_loanSituation2.setStyle("-fx-alignment: CENTER");
		colB_loanSituation2.setCellValueFactory(new PropertyValueFactory<>("b_loansituation"));

		// ���̺��� ������ �ֱ�
		totalList();
		tableView.setItems(data);
		tableView.getColumns().addAll(colB_num, colB_name, colB_authorMatter, colB_publicationMatter, colB_group,
				colB_registerNum, colB_ISBN, colB_dataType, colB_loanSituation);
		tableView2.setItems(data2);
		tableView2.getColumns().addAll(colB_num1, colB_name1, colB_authorMatter1, colB_publicationMatter1, colB_group1,
				colB_registerNum1, colB_ISBN1, colB_dataType1, colB_loanSituation1);

		tableView3.getColumns().addAll(colB_num2, colB_name2, colB_authorMatter2, colB_publicationMatter2, colB_group2,
				colB_registerNum2, colB_ISBN2, colB_dataType2, colB_loanSituation2);
		tableView3.setItems(dataloan);
		totalList3();
		totalList4();

		TableColumn colNum = new TableColumn("ȸ�� ��ȣ");
		colNum.setMaxWidth(60);
		colNum.setStyle("-fx-alignment: CENTER");
		colNum.setCellValueFactory(new PropertyValueFactory<>("mnum"));

		TableColumn colName = new TableColumn("ȸ�� ��");
		colName.setMaxWidth(100);
		colName.setStyle("-fx-alignment: CENTER");
		colName.setCellValueFactory(new PropertyValueFactory<>("name"));
		TableColumn colBirth = new TableColumn("�������");
		colBirth.setMinWidth(70);
		colBirth.setStyle("-fx-alignment: CENTER");
		colBirth.setCellValueFactory(new PropertyValueFactory<>("birth"));
		TableColumn colPhone = new TableColumn("����ó");
		colPhone.setMinWidth(150);
		colPhone.setStyle("-fx-alignment: CENTER");
		colPhone.setCellValueFactory(new PropertyValueFactory<>("phone"));
		TableColumn colGender = new TableColumn("����");
		colGender.setMaxWidth(40);
		colGender.setStyle("-fx-alignment: CENTER");
		colGender.setCellValueFactory(new PropertyValueFactory<>("gender"));

		TableColumn colEmail = new TableColumn("�̸���");
		colEmail.setMinWidth(150);
		colEmail.setStyle("-fx-alignment: CENTER");
		colEmail.setCellValueFactory(new PropertyValueFactory<>("email"));

		TableColumn colAddress = new TableColumn("�ּ�");
		colAddress.setMinWidth(195);
		colAddress.setStyle("-fx-alignment: CENTER");
		colAddress.setCellValueFactory(new PropertyValueFactory<>("address"));

		TableColumn colRegisterDate = new TableColumn("�����");
		colRegisterDate.setMinWidth(100);
		colRegisterDate.setStyle("-fx-alignment: CENTER");
		colRegisterDate.setCellValueFactory(new PropertyValueFactory<>("registerDate"));

		TableColumn colNote = new TableColumn("���൵��");
		colNote.setMinWidth(135);
		colNote.setStyle("-fx-alignment: CENTER");
		colNote.setCellValueFactory(new PropertyValueFactory<>("note"));

		tableView1.setItems(data1);
		tableView1.getColumns().addAll(colNum, colName, colBirth, colPhone, colGender, colEmail, colAddress,
				colRegisterDate, colNote);
		totalList1();

		// �뿩�ݳ�â �������

		// ���� ���� ����
		btnB_ok.setOnAction(event -> {
			try {
				data.removeAll(data);
				BooksVO bvo = null;
				BooksDAO bdao = null;

				if (event.getSource().equals(btnB_ok)) {

					bvo = new BooksVO(txtB_name.getText(), txtB_dataType.getText(), txtB_group.getText(),
							txtB_authorMatter.getText(), txtB_publicationMatter.getText(), txtB_ISBN.getText(),
							txtB_registerNum.getText(), txtB_loanSituation.getText());
					bdao = new BooksDAO();

					bdao.getBooksregiste(bvo);
					totalList();
				}

				txtB_num.clear();
				txtB_name.clear();
				txtB_authorMatter.clear();
				txtB_publicationMatter.clear();
				txtB_dataType.clear();
				txtB_group.clear();
				txtB_ISBN.clear();
				txtB_registerNum.clear();
				txtB_loanSituation.clear();

			} catch (Exception e) {
				Alert alert = new Alert(AlertType.WARNING);
				alert.setTitle("���� ���� �Է�");
				alert.setHeaderText("���� ������ ��Ȯ�� �Է��ϼ���");
				alert.setContentText("���õ� ������");
				alert.showAndWait();
				totalList();
			}

		});

		// ȸ�� ���
		btnOk.setOnAction(event -> {
			try {

				Date date = new Date();
				SimpleDateFormat sdf = new SimpleDateFormat("YYYY��-MMMM-dd��");
				txtRegisterDate.setText(sdf.format(date));

				data1.removeAll(data1);
				MembersVO mVo = null;
				MembersDAO mDao = null;

				if (event.getSource().equals(btnOk)) {
					mVo = new MembersVO(txtName.getText(), Integer.parseInt(txtBirth.getText()), txtPhone.getText(),
							txtGender.getText(), txtEmail.getText(), txtAddress.getText(), txtRegisterDate.getText(),
							txtNote.getText());
					mDao = new MembersDAO();
					mDao.getMembersregiste(mVo);
					totalList1();
				}

				txtMnum.clear();
				txtName.clear();
				txtGender.clear();
				txtBirth.clear();
				txtPhone.clear();
				txtAddress.clear();
				txtEmail.clear();
				txtRegisterDate.clear();
				txtNote.clear();

			} catch (Exception e) {
				Alert alert = new Alert(AlertType.WARNING);
				alert.setTitle("ȸ�� ���� �Է�");
				alert.setHeaderText("ȸ�� ������ ��Ȯ�� �Է��ϼ���");
				alert.setContentText("���õ� ������");
				alert.showAndWait();
				totalList1();
			}

		});
		// ���콺 ȸ��Ŭ�� �̺�Ʈ
		tableView1.setOnMousePressed(new EventHandler<MouseEvent>() {
			public void handle(MouseEvent me) {
				selectMember = tableView1.getSelectionModel().getSelectedItems();
				selectedIndex = tableView1.getSelectionModel().getSelectedIndex();

				try {
					btnEdit.setDisable(false);
					btnDelete.setDisable(false);
					btnInquiry.setDisable(false);

					txtMnum.setText(selectMember.get(0).getMnum() + "");
					txtName.setText(selectMember.get(0).getName());
					txtGender.setText(selectMember.get(0).getGender());
					txtBirth.setText(selectMember.get(0).getBirth() + "");
					txtPhone.setText(selectMember.get(0).getPhone());
					txtAddress.setText(selectMember.get(0).getAddress());
					txtEmail.setText(selectMember.get(0).getEmail());
					txtRegisterDate.setText(selectMember.get(0).getRegisterDate());
					txtNote.setText(selectMember.get(0).getNote());

					txtRegisterDate.setEditable(false);

				} catch (Exception e) {
				}
			}
		});

		// ���콺 ���� Ŭ�� �̺�Ʈ
		tableView.setOnMousePressed(new EventHandler<MouseEvent>() {
			public void handle(MouseEvent me) {
				selectBook = tableView.getSelectionModel().getSelectedItems();
				selectedIndex = tableView.getSelectionModel().getSelectedIndex();
				btnB_edit.setDisable(false);
				btnB_reservation.setDisable(false);
				btnB_delete.setDisable(false);

				try {
					txtB_num.setText(selectBook.get(0).getB_num() + "");
					txtB_name.setText(selectBook.get(0).getB_name());
					txtB_authorMatter.setText(selectBook.get(0).getB_authormatter());
					txtB_publicationMatter.setText(selectBook.get(0).getB_publicationmatter());
					txtB_dataType.setText(selectBook.get(0).getB_datatype());
					txtB_group.setText(selectBook.get(0).getB_group());
					txtB_ISBN.setText(selectBook.get(0).getB_isbn() + "");
					txtB_registerNum.setText(selectBook.get(0).getB_registernum());
					txtB_loanSituation.setText(selectBook.get(0).getB_loansituation());

				} catch (Exception e) {

				}
			}
		});

		// ���̺���3 ���콺 Ŭ�� �̺�Ʈ
		tableView3.setOnMousePressed(new EventHandler<MouseEvent>() {
			public void handle(MouseEvent me) {

				try {
					btnL_return.setDisable(false);
					selectBook = tableView3.getSelectionModel().getSelectedItems();

				} catch (Exception e) {

				}

			}

		});

		// ���̺���2 ���콺 Ŭ�� �̺�Ʈ
		tableView2.setOnMousePressed(new EventHandler<MouseEvent>() {
			public void handle(MouseEvent me) {
				try {

					btnL_loan.setDisable(false);
					selectBook = tableView2.getSelectionModel().getSelectedItems();

				} catch (Exception e) {

				}

			}

		});

		// ��ư �̺�Ʈ����
		btnB_reset.setOnAction(event -> handlerBtnB_resetAction(event));
		btnB_search.setOnAction(event -> handlerBtnB_searchAction(event));
		btnB_edit.setOnAction(event -> handlerBtnB_editAction(event));
		btnB_delete.setOnAction(event -> handlerBtnB_deleteAction(event));
		btnB_reservation.setOnAction(event -> handlerBtnB_reservationAction(event));

		btnReset.setOnAction(event -> handlerBtnResetAction(event));
		btnSearch.setOnAction(event -> handlerBtnSearchAction(event));
		btnEdit.setOnAction(event -> handlerBtnEditAction(event));
		btnDelete.setOnAction(event -> handlerBtnDeleteAction(event));

		btnL_search.setOnAction(event -> handlerBtnL_searchAction(event));
		btnL_loan.setOnAction(event -> handlerBtnL_loanAction(event));
		btnL_return.setOnAction(event -> handlerBtnL_returnAction(event));
		btnL_reset.setOnAction(event -> handlerBtnL_resetAction(event));
		btnInquiry.setOnAction(event -> handlerBtnInquiryAction(event));
	}

	// ���� ���� ���â

	public void handlerBtnB_reservationAction(ActionEvent event) {

		try {

			FXMLLoader loader = new FXMLLoader();
			loader.setLocation(getClass().getResource("/view/reservation.fxml"));

			Stage dialog = new Stage(StageStyle.UTILITY);
			dialog.initModality(Modality.WINDOW_MODAL);
			dialog.initOwner(btnOk.getScene().getWindow());
			dialog.setTitle("ȸ��ã��");

			Parent parentEdit = (Parent) loader.load();
			MembersVO MembersEdit = tableViewR.getSelectionModel().getSelectedItem();
			selectedIndex = tableViewR.getSelectionModel().getSelectedIndex();

			TableView<MembersVO> tableViewR = (TableView) parentEdit.lookup("#tableViewR");

			TableColumn colNum = new TableColumn("ȸ�� ��ȣ");
			colNum.setMaxWidth(60);
			colNum.setStyle("-fx-alignment: CENTER");
			colNum.setCellValueFactory(new PropertyValueFactory<>("mnum"));

			TableColumn colName = new TableColumn("ȸ�� ��");
			colName.setMaxWidth(100);
			colName.setStyle("-fx-alignment: CENTER");
			colName.setCellValueFactory(new PropertyValueFactory<>("name"));

			TableColumn colBirth = new TableColumn("�������");
			colBirth.setMinWidth(188);
			colBirth.setStyle("-fx-alignment: CENTER");
			colBirth.setCellValueFactory(new PropertyValueFactory<>("birth"));

			TableColumn colPhone = new TableColumn("����ó");
			colPhone.setMinWidth(150);
			colPhone.setStyle("-fx-alignment: CENTER");

			colPhone.setCellValueFactory(new PropertyValueFactory<>("phone"));
			tableViewR.setItems(data3);
			tableViewR.getColumns().addAll(colNum, colName, colBirth, colPhone);

			data3.removeAll(data3);
			totalListR();

			Button btnR_search = (Button) parentEdit.lookup("#btnR_search");
			Button btnReservation = (Button) parentEdit.lookup("#btnReservation");
			Button btnR_cancel = (Button) parentEdit.lookup("#btnR_cancel");

			// ���â �˻�
			btnR_search.setOnAction(e -> {

				Object[][] totalData = null;
				boolean searchResult = false;

				String searchName = "";
				String searchNum = "";

				TextField name = (TextField) parentEdit.lookup("#txtName");
				TextField num = (TextField) parentEdit.lookup("#txtNum");

				try {
					if (!name.equals("") || !num.equals("")) {
						searchName = name.getText().trim();
						searchNum = num.getText().trim();
						mVo = mDao.getMembersCheck(searchName);
						mVo1 = mDao.getMembersCheck1(searchNum);
						if (mVo1 != null && mVo == null) {

							ArrayList<String> title;
							ArrayList<MembersVO> list;

							title = mDao.getColumnName();
							int columnCount = title.size();

							list = mDao.getMembersTotal();
							int rowCount = list.size();

							totalData = new Object[rowCount][columnCount];

							if ((mVo1.getMnum() + "").equals(searchNum)) {
								txtNum1.clear();
								data1.removeAll(data1);
								for (int index = 0; index < rowCount; index++) {
									mVo1 = list.get(index);
									if ((mVo1.getMnum() + "").equals(searchNum)) {
										data1.add(mVo1);

										searchResult = true;

									}
								}
							}
						}

						if (mVo != null && mVo1 == null) {

							ArrayList<String> title;
							ArrayList<MembersVO> list;

							title = mDao.getColumnName();
							int columnCount = title.size();

							list = mDao.getMembersTotal();
							int rowCount = list.size();

							totalData = new Object[rowCount][columnCount];

							if (mVo.getName().equals(searchName)) {
								txtName1.clear();
								data1.removeAll(data1);
								for (int index = 0; index < rowCount; index++) {
									mVo = list.get(index);
									if (mVo.getName().equals(searchName)) {
										data1.add(mVo);
										searchResult = true;

									}
								}
							}
						}
					}

					if (mVo != null && mVo1 != null) {

						ArrayList<String> title;
						ArrayList<MembersVO> list;

						title = mDao.getColumnName();
						int columnCount = title.size();

						list = mDao.getMembersTotal();
						int rowCount = list.size();

						totalData = new Object[rowCount][columnCount];

						if ((mVo1.getMnum() + "").equals(searchNum) && (mVo.getName().equals(searchName))) {
							txtNum1.clear();
							txtName1.clear();
							data1.removeAll(data1);
							for (int index = 0; index < rowCount; index++) {
								mVo = list.get(index);
								if (mVo.getName().equals(searchName)) {
									data1.add(mVo);
								}
							}
							for (int index1 = 0; index1 < rowCount; index1++) {
								mVo1 = list.get(index1);
								if ((mVo1.getMnum() + "").equals(searchNum)) {
									data1.add(mVo1);
									searchResult = true;
								}

							}
						}
					}

					if (!searchResult) {
						txtName1.clear();
						Alert alert = new Alert(AlertType.INFORMATION);
						alert.setTitle("ȸ�� ���� �˻�");
						alert.setHeaderText("����Ʈ�� �̸� �����ϴ�.");
						alert.setContentText("�ٽ� �˻��ϼ���.");
						alert.showAndWait();
					}
				} catch (Exception f) {
					f.printStackTrace();
				}
			});

			// ����
			btnReservation.setOnAction(e -> {

				MembersDAO mDao = new MembersDAO();
				MembersVO mVo = new MembersVO();
				BooksVO bVo = new BooksVO();
				BooksDAO bDao = new BooksDAO();

				ArrayList<MembersVO> list;

				list = mDao.getMembersTotal();
				int rowCount = list.size();
				System.out.println("�ȵ�");
				for (int index = 0; index < rowCount; index++) {
					mVo = list.get(index);
					System.out.println("��");
					if (mVo.getNote() == selectBook.get(0).getB_name()) {
						System.out.println(mVo.getNote());
						System.out.println(selectBook.get(0).getB_name());
						Alert alert = new Alert(AlertType.WARNING);
						alert.setTitle("�Ұ���");
						alert.setContentText("�����ڰ� �־� �̾���.");
						alert.showAndWait();
						return;
					}

				}

				try {
					selectMember = tableViewR.getSelectionModel().getSelectedItems();
					selectedIndex = tableViewR.getSelectionModel().getSelectedIndex();

					txtMnum.setText(selectMember.get(0).getMnum() + "");
					txtName.setText(selectMember.get(0).getName());
					txtGender.setText(selectMember.get(0).getGender());
					txtBirth.setText(selectMember.get(0).getBirth() + "");
					txtPhone.setText(selectMember.get(0).getPhone());
					txtAddress.setText(selectMember.get(0).getAddress());
					txtEmail.setText(selectMember.get(0).getEmail());
					txtNote.setText(selectBook.get(0).getB_name());

					mVo = new MembersVO(Integer.parseInt(txtMnum.getText().trim()), txtName.getText(),
							Integer.parseInt(txtBirth.getText()), txtPhone.getText(), txtGender.getText(),
							txtEmail.getText(), txtAddress.getText(), txtRegisterDate.getText(), txtNote.getText());

					mDao.getMembersUpdate(mVo, mVo.getMnum());

					dialog.close();
					return;

				} catch (Exception f) {
					f.printStackTrace();

				}

			});

			// ����â �ݱ�
			btnR_cancel.setOnAction(e -> {
				dialog.close();
			});

			Scene scene = new Scene(parentEdit);
			dialog.setScene(scene);
			dialog.setResizable(false);
			dialog.show();

		} catch (

		IOException e) {
			System.out.println(e.toString());
		}

	}

	// �ݳ� ��ư
	public void handlerBtnL_returnAction(ActionEvent event) {
		FXMLLoader loader = new FXMLLoader();
		loader.setLocation(getClass().getResource("/view/return.fxml"));
		Stage dialog = new Stage(StageStyle.UTILITY);
		dialog.initModality(Modality.WINDOW_MODAL);
		dialog.initOwner(btnOk.getScene().getWindow());
		dialog.setTitle("�ݳ�Ȯ��");
		Parent parentEdit = null;
		try {
			parentEdit = (Parent) loader.load();
		} catch (IOException e1) {
			e1.printStackTrace();
		}

		Scene scene = new Scene(parentEdit);
		dialog.setScene(scene);
		dialog.setResizable(false);
		dialog.show();

		Button btnReturnOk = (Button) parentEdit.lookup("#btnReturnOk");
		Button btnReturnCancel = (Button) parentEdit.lookup("#btnReturnCancel");

		btnReturnOk.setOnAction(e -> {
			BooksVO bVo;
			BooksDAO bDao = new BooksDAO();
			InfoVO ivo;
			InfoDAO idao = new InfoDAO();
			ArrayList<BooksVO> list = new ArrayList<>();
			try {
				selectBook = tableView3.getSelectionModel().getSelectedItems();
				String loan = null;
				int no = selectBook.get(0).getB_num();
				bDao.loanUpdate(loan, no);

				dataloan.removeAll(dataloan);
				list = bDao.loansituation();
				int count = list.size();

				for (int i = 0; i < count; i++) {
					bVo = list.get(i);
					dataloan.addAll(bVo);
				}

				data2.removeAll(data2);
				list = bDao.keepList();
				int count1 = list.size();
				for (int i = 0; i < count1; i++) {
					bVo = list.get(i);
					data2.addAll(bVo);
				}

				idao.getInfoDelete(no);
				dialog.close();

			} catch (Exception ex) {
				ex.printStackTrace();
			}

		});

		btnReturnCancel.setOnAction(e -> {
			dialog.close();
		});

	}

	// �뿩 ��ư@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
	public void handlerBtnL_loanAction(ActionEvent event) {

		MembersVO mvo = new MembersVO();

		ArrayList<String> title;
		ArrayList<MembersVO> list;

		title = mDao.getColumnName();
		int columnCount = title.size();

		list = mDao.getMembersTotal();
		int rowCount = list.size();

		for (int index = 0; index < rowCount; index++) {
			mvo = list.get(index);

			if (selectBook.get(0).getB_name().equals(mvo.getNote())) {
				Alert alert = new Alert(AlertType.WARNING);
				alert.setTitle("�Ұ���");
				alert.setContentText("�����ڰ� �־� �̾���.");
				alert.showAndWait();
				return;
			}

		}
		try {

			FXMLLoader loader = new FXMLLoader();
			loader.setLocation(getClass().getResource("/view/reservation.fxml"));

			Stage dialog = new Stage(StageStyle.UTILITY);
			dialog.initModality(Modality.WINDOW_MODAL);
			dialog.initOwner(btnOk.getScene().getWindow());
			dialog.setTitle("�뿩");

			Parent parentEdit = (Parent) loader.load();
			MembersVO MembersEdit = tableViewR.getSelectionModel().getSelectedItem();
			selectedIndex = tableViewR.getSelectionModel().getSelectedIndex();
			TableView<MembersVO> tableViewR = (TableView) parentEdit.lookup("#tableViewR");

			TableColumn colNum = new TableColumn("ȸ�� ��ȣ");
			colNum.setMaxWidth(60);
			colNum.setStyle("-fx-alignment: CENTER");
			colNum.setCellValueFactory(new PropertyValueFactory<>("mnum"));

			TableColumn colName = new TableColumn("ȸ�� ��");
			colName.setMaxWidth(100);
			colName.setStyle("-fx-alignment: CENTER");
			colName.setCellValueFactory(new PropertyValueFactory<>("name"));

			TableColumn colBirth = new TableColumn("�������");
			colBirth.setMinWidth(188);
			colBirth.setStyle("-fx-alignment: CENTER");
			colBirth.setCellValueFactory(new PropertyValueFactory<>("birth"));

			TableColumn colPhone = new TableColumn("����ó");
			colPhone.setMinWidth(150);
			colPhone.setStyle("-fx-alignment: CENTER");
			colPhone.setCellValueFactory(new PropertyValueFactory<>("phone"));

			tableViewR.setItems(data3);
			tableViewR.getColumns().addAll(colNum, colName, colBirth, colPhone);

			data3.removeAll(data3);
			totalListR();

			Button btnR_search = (Button) parentEdit.lookup("#btnR_search");
			Button btnReservation = (Button) parentEdit.lookup("#btnReservation");
			Button btnR_cancel = (Button) parentEdit.lookup("#btnR_cancel");

			// ���â �˻�
			btnR_search.setOnAction(e -> {

				Object[][] totalData = null;
				boolean searchResult = false;

				String searchName = "";
				String searchNum = "";

				TextField name = (TextField) parentEdit.lookup("#txtName");
				TextField num = (TextField) parentEdit.lookup("#txtNum");

				try {
					if (!name.equals("") || !num.equals("")) {
						searchName = name.getText().trim();
						searchNum = num.getText().trim();
						mVo = mDao.getMembersCheck(searchName);
						mVo1 = mDao.getMembersCheck1(searchNum);
						if (mVo1 != null && mVo == null) {

							/*
							 * ArrayList<String> title; ArrayList<MembersVO> list;
							 */

							if ((mVo1.getMnum() + "").equals(searchNum)) {
								txtNum1.clear();
								data1.removeAll(data1);
								for (int index1 = 0; index1 < rowCount; index1++) {
									mVo1 = list.get(index1);
									if ((mVo1.getMnum() + "").equals(searchNum)) {
										data1.add(mVo1);

										searchResult = true;

									}
								}
							}
						}

						if (mVo != null && mVo1 == null) {

							/*
							 * ArrayList<String> title; ArrayList<MembersVO> list;
							 */

							totalData = new Object[rowCount][columnCount];

							if (mVo.getName().equals(searchName)) {
								txtName1.clear();
								data1.removeAll(data1);
								for (int index2 = 0; index2 < rowCount; index2++) {
									mVo = list.get(index2);
									if (mVo.getName().equals(searchName)) {
										data1.add(mVo);
										searchResult = true;

									}
								}
							}
						}
					}

					if (mVo != null && mVo1 != null) {

						/*
						 * ArrayList<String> title; ArrayList<MembersVO> list;
						 */

						totalData = new Object[rowCount][columnCount];

						if ((mVo1.getMnum() + "").equals(searchNum) && (mVo.getName().equals(searchName))) {
							txtNum1.clear();
							txtName1.clear();
							data1.removeAll(data1);
							for (int index3 = 0; index3 < rowCount; index3++) {
								mVo = list.get(index3);
								if (mVo.getName().equals(searchName)) {
									data1.add(mVo);
								}
							}
							for (int index4 = 0; index4 < rowCount; index4++) {
								mVo1 = list.get(index4);
								if ((mVo1.getMnum() + "").equals(searchNum)) {
									data1.add(mVo1);
									searchResult = true;
								}

							}
						}
					}

					if (!searchResult) {
						txtName1.clear();
						Alert alert = new Alert(AlertType.INFORMATION);
						alert.setTitle("ȸ�� ���� �˻�");
						alert.setHeaderText("����Ʈ�� �̸� �����ϴ�.");
						alert.setContentText("�ٽ� �˻��ϼ���.");
						alert.showAndWait();
					}
				} catch (Exception f) {
					f.printStackTrace();
				}
			});

			// �������� �뿩
			btnReservation.setOnAction(e -> {

				MembersDAO mDao = new MembersDAO();
				MembersVO mVo = new MembersVO();
				BooksVO bVo = new BooksVO();
				BooksDAO bDao = new BooksDAO();
				InfoDAO iDao = new InfoDAO();
				InfoVO iVo = null;
				ArrayList<BooksVO> listbook = new ArrayList<>();

				try {

					selectBook = tableView2.getSelectionModel().getSelectedItems();
					selectMember = tableViewR.getSelectionModel().getSelectedItems();
					selectedIndex = tableViewR.getSelectionModel().getSelectedIndex();

					int no = selectMember.get(0).getMnum();
					iDao.limit(no);
					int limit = iDao.limit(no);

					if (limit > 1) {
						Alert alert = new Alert(AlertType.INFORMATION);
						alert.setTitle("���");
						alert.setHeaderText("�뿩 ���� �� �ʰ�");
						alert.setContentText("���� �뿩���� ������ �ݳ��ϼ���.");
						alert.showAndWait();
					} else {

						iVo = new InfoVO(selectBook.get(0).getB_num(), selectMember.get(0).getMnum(),
								selectBook.get(0).getB_name());

						iDao.getInfoRegiste(iVo);
						dataI.add(iVo);

						String loan = "����";
						no = selectBook.get(0).getB_num();

						bDao.loanUpdate(loan, no);

						dataloan.removeAll(dataloan);
						listbook = bDao.loansituation();
						int count = listbook.size();
						for (int i = 0; i < count; i++) {
							bVo = listbook.get(i);
							dataloan.addAll(bVo);

						}
						data2.removeAll(data2);
						listbook = bDao.loansituationnull();
						int count1 = listbook.size();
						for (int i = 0; i < count1; i++) {
							bVo = listbook.get(i);
							data2.addAll(bVo);
						}

						dialog.close();

					}

				} catch (Exception f) {
					f.printStackTrace();
				}

			});

			// ����â �ݱ�
			btnR_cancel.setOnAction(e -> {
				dialog.close();
			});

			Scene scene = new Scene(parentEdit);
			dialog.setScene(scene);
			dialog.setResizable(false);
			dialog.show();

			return;
		} catch (IOException e) {
			System.out.println(e.toString());
		}

	}

	// �뿩 â ���ΰ�ħ
	public void handlerBtnL_resetAction(ActionEvent evnet) {
		txtB_searchName.clear();
		txtB_searchNum.clear();
		btnL_loan.setDisable(true);
		btnL_return.setDisable(true);
		data2.removeAll(data2);
		dataloan.removeAll(dataloan);
		totalList3();
		totalList4();
	}

	// ��ȸ ��ư
	public void handlerBtnInquiryAction(ActionEvent event) {

		try {

			FXMLLoader loader = new FXMLLoader();
			loader.setLocation(getClass().getResource("/view/info.fxml"));

			Stage dialog = new Stage(StageStyle.UTILITY);
			dialog.initModality(Modality.WINDOW_MODAL);
			dialog.initOwner(btnOk.getScene().getWindow());
			dialog.setTitle("�뿩��ȸ");

			Parent parentEdit = (Parent) loader.load();
			TableView<InfoVO> tableViewI = (TableView) parentEdit.lookup("#tableViewI");

			InfoVO ivo = new InfoVO();

			TableColumn colI_num = new TableColumn("No.");
			colI_num.setMaxWidth(60);
			colI_num.setStyle("-fx-alignment: CENTER");
			colI_num.setCellValueFactory(new PropertyValueFactory<>("I_num"));

			TableColumn colB_numI = new TableColumn("������ȣ");
			colB_numI.setMaxWidth(100);
			colB_numI.setStyle("-fx-alignment: CENTER");
			colB_numI.setCellValueFactory(new PropertyValueFactory<>("B_num"));

			TableColumn colB_name = new TableColumn("������");
			colB_name.setMinWidth(140);
			colB_name.setStyle("-fx-alignment: CENTER");
			colB_name.setCellValueFactory(new PropertyValueFactory<>("B_name"));

			TableColumn colLoanDate = new TableColumn("�뿩��");
			colLoanDate.setMinWidth(150);
			colLoanDate.setStyle("-fx-alignment: CENTER");
			colLoanDate.setCellValueFactory(new PropertyValueFactory<>("LoanDate"));

			TableColumn colReturnDate = new TableColumn("�ݳ���");
			colReturnDate.setMinWidth(150);
			colReturnDate.setStyle("-fx-alignment: CENTER");
			colReturnDate.setCellValueFactory(new PropertyValueFactory<>("ReturnDate"));

			tableViewI.getColumns().addAll(colI_num, colB_numI, colB_name, colLoanDate, colReturnDate);
			tableViewI.setItems(dataI);
			loanBook();

			Scene scene = new Scene(parentEdit);
			dialog.setScene(scene);
			dialog.setResizable(false);
			dialog.show();
		} catch (Exception e) {

		}
	}

	private TextField setText(String text) {
		// TODO Auto-generated method stub
		return null;
	}

	// ȸ��������ư
	public void handlerBtnEditAction(ActionEvent event) {

		MembersVO mVo = new MembersVO();
		MembersDAO mDao = new MembersDAO();

		try {
			data1.remove(selectedIndex);
			mVo = new MembersVO(Integer.parseInt(txtMnum.getText().trim()), txtName.getText(),
					Integer.parseInt(txtBirth.getText()), txtPhone.getText(), txtGender.getText(), txtEmail.getText(),
					txtAddress.getText(), txtRegisterDate.getText(), txtNote.getText());

			mDao.getMembersUpdate(mVo, mVo.getMnum());

			data1.add(mVo);

		} catch (Exception e) {
			Alert alert = new Alert(AlertType.WARNING);
			alert.setTitle("�л� ���� ����");
			alert.setHeaderText("�����Ǵ� ������ ��Ȯ�� �Է��Ͻÿ�.");
			alert.setContentText("�������� �����ϼ���!");
			alert.showAndWait();
		}
	}

	// ����������ư
	public void handlerBtnB_editAction(ActionEvent event) {
		BooksVO bVo = new BooksVO();
		BooksDAO bDao = new BooksDAO();

		try {
			data.remove(selectedIndex);
			bVo = new BooksVO(Integer.parseInt(txtB_num.getText().trim()), txtB_name.getText(), txtB_dataType.getText(),
					txtB_group.getText(), txtB_authorMatter.getText(), txtB_publicationMatter.getText(),
					txtB_ISBN.getText(), txtB_registerNum.getText(), txtB_loanSituation.getText());

			bDao.getBooksUpdate(bVo, bVo.getB_num());

			data.add(bVo);
			btnB_edit.setDisable(true);
		} catch (Exception e) {
			Alert alert = new Alert(AlertType.WARNING);
			alert.setTitle("�л� ���� ����");
			alert.setHeaderText("�����Ǵ� ������ ��Ȯ�� �Է��Ͻÿ�.");
			alert.setContentText("�������� �����ϼ���!");
			alert.showAndWait();
		}
	}

	// ȸ�� �˻� ��ư
	public void handlerBtnSearchAction(ActionEvent event) {
		MembersVO mVo = new MembersVO();
		MembersVO mVo1 = new MembersVO();
		MembersDAO mDao = new MembersDAO();
		Object[][] totalData = null;
		boolean searchResult = false;

		String searchName = "";
		String searchNum = "";

		try {
			if (!txtName1.equals("") || !txtNum1.equals("")) {
				searchName = txtName1.getText().trim();
				searchNum = txtNum1.getText().trim();
				mVo = mDao.getMembersCheck(searchName);
				mVo1 = mDao.getMembersCheck1(searchNum);
				if (mVo1 != null && mVo == null) {

					ArrayList<String> title;
					ArrayList<MembersVO> list;

					title = mDao.getColumnName();
					int columnCount = title.size();

					list = mDao.getMembersTotal();
					int rowCount = list.size();

					totalData = new Object[rowCount][columnCount];

					if ((mVo1.getMnum() + "").equals(searchNum)) {
						txtNum1.clear();
						data1.removeAll(data1);
						for (int index = 0; index < rowCount; index++) {
							mVo1 = list.get(index);
							if ((mVo1.getMnum() + "").equals(searchNum)) {
								data1.add(mVo1);
								searchResult = true;

							}
						}
					}
				}

				if (mVo != null && mVo1 == null) {

					ArrayList<String> title;
					ArrayList<MembersVO> list;

					title = mDao.getColumnName();
					int columnCount = title.size();

					list = mDao.getMembersTotal();
					int rowCount = list.size();

					totalData = new Object[rowCount][columnCount];

					if (mVo.getName().equals(searchName)) {
						txtName1.clear();
						data1.removeAll(data1);
						for (int index = 0; index < rowCount; index++) {
							mVo = list.get(index);
							if (mVo.getName().equals(searchName)) {
								data1.add(mVo);
								searchResult = true;

							}
						}
					}
				}
			}

			if (mVo != null && mVo1 != null) {

				ArrayList<String> title;
				ArrayList<MembersVO> list;

				title = mDao.getColumnName();
				int columnCount = title.size();

				list = mDao.getMembersTotal();
				int rowCount = list.size();

				totalData = new Object[rowCount][columnCount];

				if ((mVo1.getMnum() + "").equals(searchNum) && (mVo.getName().equals(searchName))) {
					txtNum1.clear();
					txtName1.clear();
					data1.removeAll(data1);
					for (int index = 0; index < rowCount; index++) {
						mVo = list.get(index);
						if (mVo.getName().equals(searchName)) {
							data1.add(mVo);
						}
					}
					for (int index1 = 0; index1 < rowCount; index1++) {
						mVo1 = list.get(index1);
						if ((mVo1.getMnum() + "").equals(searchNum)) {
							data1.add(mVo1);
							searchResult = true;
						}

					}
				}
			}

			if (!searchResult) {
				txtName1.clear();

			}
		} catch (

		Exception e) {
			e.printStackTrace();
		}
	}

	// ���� �˻� ��ư
	public void handlerBtnB_searchAction(ActionEvent event) {

		BooksVO bVo = new BooksVO();
		BooksDAO bDao = new BooksDAO();

		Object[][] totalData = null;

		String searchName = "";
		String searchNum = "";
		boolean searchResult = false;

		try {
			if (txtB_name1.getText().length() != 0 && txtB_num1.getText().length() == 0) {
				searchName = txtB_name1.getText().trim();
				bVo = bDao.getBooksCheck(searchName);

				if (!searchName.equals("") && (bVo != null)) {
					ArrayList<String> title;
					ArrayList<BooksVO> list;

					title = bDao.getColumnName();
					int columnCount = title.size();

					list = bDao.getBooksTotal();
					int rowCount = list.size();

					totalData = new Object[rowCount][columnCount];

					if (bVo.getB_name().equals(searchName)) {
						txtB_name1.clear();
						data.removeAll(data);
						for (int index = 0; index < rowCount; index++) {
							bVo = list.get(index);
							if (bVo.getB_name().equals(searchName)) {
								data.add(bVo);
								searchResult = true;

							}
						}
					}
				}

				if (!searchResult) {
					txtB_name1.clear();
					Alert alert = new Alert(AlertType.INFORMATION);
					alert.setTitle("���� ���� �˻�");
					alert.setHeaderText("����Ʈ�� �̸� �����ϴ�.");
					alert.setContentText("�ٽ� �˻��ϼ���.");
					alert.showAndWait();
				}
			}
			// ------------------------------------------------------

			if (txtB_num1.getText().length() != 0 && txtB_name1.getText().length() == 0) {

				if (txtB_num1.getText().length() != 0) {
					searchNum = txtB_num1.getText().trim();

					bVo = bDao.getBooksCheck1(searchNum);

					if (!searchNum.equals("") && (bVo != null)) {
						ArrayList<String> title;
						ArrayList<BooksVO> list;

						title = bDao.getColumnName();
						int columnCount = title.size();

						list = bDao.getBooksTotal();
						int rowCount = list.size();

						totalData = new Object[rowCount][columnCount];

						if ((bVo.getB_num() + "").equals(searchNum)) {
							txtB_num1.clear();
							data.removeAll(data);
							for (int index = 0; index < rowCount; index++) {
								bVo = list.get(index);
								if ((bVo.getB_num() + "").equals(searchNum)) {
									data.add(bVo);
									searchResult = true;

								}
							}
						}
					}

					if (!searchResult) {
						txtB_num1.clear();
						Alert alert = new Alert(AlertType.INFORMATION);
						alert.setTitle("���� ���� �˻�");
						alert.setHeaderText("����Ʈ�� ��ȣ �����ϴ�.");
						alert.setContentText("�ٽ� �˻��ϼ���.");
						alert.showAndWait();
					}

				}

			}
			if (txtB_num1.getText().length() != 0 && txtB_name1.getText().length() != 0) {
				searchName = txtB_name1.getText().trim();
				bVo = bDao.getBooksCheck(searchName);

				if (!searchName.equals("") && (bVo != null)) {
					ArrayList<String> title;
					ArrayList<BooksVO> list;

					title = bDao.getColumnName();
					int columnCount = title.size();

					list = bDao.getBooksTotal();
					int rowCount = list.size();

					totalData = new Object[rowCount][columnCount];

					if (bVo.getB_name().equals(searchName)) {
						txtB_name1.clear();
						data.removeAll(data);
						for (int index = 0; index < rowCount; index++) {
							bVo = list.get(index);
							if (bVo.getB_name().equals(searchName)) {
								data.add(bVo);
								searchResult = true;

							}
						}
					}
				}

				if (!searchResult) {
					txtB_name1.clear();
					Alert alert = new Alert(AlertType.INFORMATION);
					alert.setTitle("���� ���� �˻�");
					alert.setHeaderText("����Ʈ�� �̸� �����ϴ�.");
					alert.setContentText("�ٽ� �˻��ϼ���.");
					alert.showAndWait();
				}

				if (txtB_num1.getText().length() != 0) {

					if (txtB_num1.getText().length() != 0) {
						searchNum = txtB_num1.getText().trim();

						bVo = bDao.getBooksCheck1(searchNum);

						if (!searchNum.equals("") && (bVo != null)) {
							ArrayList<String> title;
							ArrayList<BooksVO> list;

							title = bDao.getColumnName();
							int columnCount = title.size();

							list = bDao.getBooksTotal();
							int rowCount = list.size();

							totalData = new Object[rowCount][columnCount];

							if ((bVo.getB_num() + "").equals(searchNum)) {
								txtB_num1.clear();
								for (int index = 0; index < rowCount; index++) {
									bVo = list.get(index);
									if ((bVo.getB_num() + "").equals(searchNum)) {
										data.add(bVo);
										searchResult = true;

									}
								}
							}
						}

						if (!searchResult) {
							txtB_num1.clear();
							Alert alert = new Alert(AlertType.INFORMATION);
							alert.setTitle("���� ���� �˻�");
							alert.setHeaderText("����Ʈ�� ��ȣ �����ϴ�.");
							alert.setContentText("�ٽ� �˻��ϼ���.");
							alert.showAndWait();
						}

					}

				}
			}
		}

		catch (Exception e) {

		}
	}

	// �뿩�� ���� �˻� ��ư
	public void handlerBtnL_searchAction(ActionEvent event) {
		BooksVO bVo = new BooksVO();
		BooksDAO bDao = new BooksDAO();

		String searchName = "";
		String searchNum = "";
		boolean searchResult = false;

		try {
			if (txtB_searchName.getText().length() != 0 && txtB_searchNum.getText().length() == 0) {
				searchName = txtB_searchName.getText().trim();
				bVo = bDao.getBooksCheck(searchName);

				if (!searchName.equals("") && (bVo != null)) {
					ArrayList<String> title;
					ArrayList<BooksVO> list;

					title = bDao.getColumnName();
					int columnCount = title.size();

					list = bDao.getBooksTotal();
					int rowCount = list.size();

					if (bVo.getB_name().equals(searchName)) {
						txtB_searchName.clear();
						data2.removeAll(data2);
						dataloan.removeAll(dataloan);
						for (int index = 0; index < rowCount; index++) {
							bVo = list.get(index);
							if (bVo.getB_name().equals(searchName)) {
								data2.add(bVo);
								searchResult = true;

							}
						}
					}
				}

				if (!searchResult) {
					txtB_searchName.clear();
					Alert alert = new Alert(AlertType.INFORMATION);
					alert.setTitle("���� ���� �˻�");
					alert.setHeaderText("����Ʈ�� �̸� �����ϴ�.");
					alert.setContentText("�ٽ� �˻��ϼ���.");
					alert.showAndWait();
				}
			}
			// ------------------------------------------------------

			if (txtB_searchNum.getText().length() != 0 && txtB_searchName.getText().length() == 0) {

				if (txtB_searchNum.getText().length() != 0) {
					searchNum = txtB_searchNum.getText().trim();

					bVo = bDao.getBooksCheck1(searchNum);

					if (!searchNum.equals("") && (bVo != null)) {
						ArrayList<String> title;
						ArrayList<BooksVO> list;

						title = bDao.getColumnName();
						int columnCount = title.size();

						list = bDao.getBooksTotal();
						int rowCount = list.size();

						if ((bVo.getB_num() + "").equals(searchNum)) {
							txtB_searchNum.clear();
							data2.removeAll(data2);
							dataloan.removeAll(dataloan);
							for (int index = 0; index < rowCount; index++) {
								bVo = list.get(index);
								if ((bVo.getB_num() + "").equals(searchNum)) {
									data2.add(bVo);
									searchResult = true;

								}
							}
						}
					}

					if (!searchResult) {
						txtB_searchNum.clear();
						Alert alert = new Alert(AlertType.INFORMATION);
						alert.setTitle("���� ���� �˻�");
						alert.setHeaderText("����Ʈ�� ��ȣ �����ϴ�.");
						alert.setContentText("�ٽ� �˻��ϼ���.");
						alert.showAndWait();
					}

				}

			}
			if (txtB_searchNum.getText().length() != 0 && txtB_searchName.getText().length() != 0) {
				searchName = txtB_searchName.getText().trim();
				bVo = bDao.getBooksCheck(searchName);

				if (!searchName.equals("") && (bVo != null)) {
					ArrayList<String> title;
					ArrayList<BooksVO> list;

					title = bDao.getColumnName();
					int columnCount = title.size();

					list = bDao.getBooksTotal();
					int rowCount = list.size();

					if (bVo.getB_name().equals(searchName)) {
						txtB_searchName.clear();
						data2.removeAll(data2);
						dataloan.removeAll(dataloan);
						for (int index = 0; index < rowCount; index++) {
							bVo = list.get(index);
							if (bVo.getB_name().equals(searchName)) {
								data2.add(bVo);
								searchResult = true;

							}
						}
					}
				}

				if (!searchResult) {
					txtB_searchName.clear();
					Alert alert = new Alert(AlertType.INFORMATION);
					alert.setTitle("���� ���� �˻�");
					alert.setHeaderText("����Ʈ�� �̸� �����ϴ�.");
					alert.setContentText("�ٽ� �˻��ϼ���.");
					alert.showAndWait();
				}

				if (txtB_searchNum.getText().length() != 0) {

					if (txtB_searchNum.getText().length() != 0) {
						searchNum = txtB_searchNum.getText().trim();

						bVo = bDao.getBooksCheck1(searchNum);

						if (!searchNum.equals("") && (bVo != null)) {
							ArrayList<String> title;
							ArrayList<BooksVO> list;

							title = bDao.getColumnName();
							int columnCount = title.size();

							list = bDao.getBooksTotal();
							int rowCount = list.size();

							if ((bVo.getB_num() + "").equals(searchNum)) {
								txtB_searchNum.clear();
								for (int index = 0; index < rowCount; index++) {
									bVo = list.get(index);
									if ((bVo.getB_num() + "").equals(searchNum)) {
										data2.add(bVo);
										searchResult = true;

									}
								}
							}
						}

						if (!searchResult) {
							txtB_searchNum.clear();
							Alert alert = new Alert(AlertType.INFORMATION);
							alert.setTitle("���� ���� �˻�");
							alert.setHeaderText("����Ʈ�� ��ȣ �����ϴ�.");
							alert.setContentText("�ٽ� �˻��ϼ���.");
							alert.showAndWait();
						}
					}
				}
			}
		} catch (Exception e) {
		}
	}

	// ���ΰ�ħ
	public void handlerBtnB_resetAction(ActionEvent event) {

		txtB_num.setEditable(true);
		txtB_name.setEditable(true);
		txtB_authorMatter.setEditable(true);
		txtB_publicationMatter.setEditable(true);
		txtB_dataType.setEditable(true);
		txtB_group.setEditable(true);
		txtB_ISBN.setEditable(true);
		txtB_registerNum.setEditable(true);
		txtB_loanSituation.setEditable(true);

		txtB_num.clear();
		txtB_name.clear();
		txtB_authorMatter.clear();
		txtB_publicationMatter.clear();
		txtB_dataType.clear();
		txtB_group.clear();
		txtB_ISBN.clear();
		txtB_registerNum.clear();
		txtB_loanSituation.clear();
		btnB_edit.setDisable(true);
		btnB_reservation.setDisable(true);
		btnB_delete.setDisable(true);

		data.removeAll(data);
		totalList();

	}

	// ȸ�� ���ΰ�ħ
	public void handlerBtnResetAction(ActionEvent event) {

		btnEdit.setDisable(true);
		btnDelete.setDisable(true);
		btnInquiry.setDisable(true);
		txtMnum.setEditable(true);
		txtName.setEditable(true);
		txtGender.setEditable(true);
		txtBirth.setEditable(true);
		txtPhone.setEditable(true);
		txtAddress.setEditable(true);
		txtEmail.setEditable(true);
		txtRegisterDate.setEditable(true);
		txtNote.setEditable(true);

		txtMnum.clear();
		txtName.clear();
		txtGender.clear();
		txtBirth.clear();
		txtPhone.clear();
		txtAddress.clear();
		txtEmail.clear();
		txtRegisterDate.clear();
		txtNote.clear();
		data1.removeAll(data1);
		totalList1();

	}

	// �������� ��ü����
	public void totalList4() {
		Object[][] totalData;
		BooksDAO bDao = new BooksDAO();
		BooksVO bVo = null;

		ArrayList<String> title;
		ArrayList<BooksVO> list;

		title = bDao.getColumnName();
		int columnCount = title.size();
		list = bDao.keepList();
		int rowCount = list.size();
		totalData = new Object[rowCount][columnCount];
		for (int index = 0; index < rowCount; index++) {
			bVo = list.get(index);
			data2.add(bVo);
		}

	}

	// ���⵵�� ��ü����
	public void totalList3() {
		Object[][] totalData;
		BooksDAO bDao = new BooksDAO();
		BooksVO bVo = null;

		ArrayList<String> title;
		ArrayList<BooksVO> list;

		title = bDao.getColumnName();
		int columnCount = title.size();

		list = bDao.loanList();
		int rowCount = list.size();

		totalData = new Object[rowCount][columnCount];
		for (int index = 0; index < rowCount; index++) {
			bVo = list.get(index);
			dataloan.add(bVo);
		}
	}

	// ��ü��������
	public void totalList() {
		Object[][] totalData;

		BooksDAO bDao = new BooksDAO();
		BooksVO bVo = null;
		ArrayList<String> title;
		ArrayList<BooksVO> list;

		title = bDao.getColumnName();
		int columnCount = title.size();

		list = bDao.getBooksTotal();
		int rowCount = list.size();

		totalData = new Object[rowCount][columnCount];
		for (int index = 0; index < rowCount; index++) {
			bVo = list.get(index);
			data.add(bVo);
		}

	}

	// ��üȸ������
	public void totalList1() {
		Object[][] totalData;

		MembersDAO mDao = new MembersDAO();
		MembersVO mVo = null;
		ArrayList<String> title;
		ArrayList<MembersVO> list;

		title = mDao.getColumnName();
		int columnCount = title.size();

		list = mDao.getMembersTotal();
		int rowCount = list.size();

		totalData = new Object[rowCount][columnCount];
		for (int index = 0; index < rowCount; index++) {
			mVo = list.get(index);
			data1.add(mVo);
		}

	}

	// ��üȸ������ (�뿩)
	public void totalListR() {
		Object[][] totalData;

		MembersDAO mDao = new MembersDAO();
		MembersVO mVo = null;
		ArrayList<String> title;
		ArrayList<MembersVO> list;

		title = mDao.getColumnName();
		int columnCount = title.size();

		list = mDao.getMembersTotal();
		int rowCount = list.size();

		totalData = new Object[rowCount][columnCount];
		for (int index = 0; index < rowCount; index++) {
			mVo = list.get(index);
			data3.add(mVo);
		}

	}

	// �뿩 ��üȸ������
	public void totalListI() {
		InfoDAO iDao = new InfoDAO();
		InfoVO iVo = null;
		ArrayList<String> title;
		ArrayList<InfoVO> list;
		dataI.removeAll(dataI);
		list = iDao.getInfoTotal();
		int rowCount = list.size();
		for (int index = 0; index < rowCount; index++) {
			iVo = list.get(index);
			dataI.add(iVo);
		}

	}

	// �뿩��� ����
	public void loanBook() {
		InfoDAO iDao = new InfoDAO();
		InfoVO iVo = null;
		ArrayList<String> title;
		ArrayList<InfoVO> list;
		dataI.removeAll(dataI);
		int no = selectMember.get(0).getMnum();
		list = iDao.loanBooksCheck(no);
		int rowCount = list.size();
		for (int index = 0; index < rowCount; index++) {
			iVo = list.get(index);
			dataI.add(iVo);
		}

	}

	// ȸ������
	public void handlerBtnDeleteAction(ActionEvent event) {
		MembersDAO mDao = new MembersDAO();
		MembersVO mVo = new MembersVO();

		try {
			mDao.getMembersDelete(selectMember.get(0).getMnum());
			data1.removeAll(data1);
			totalList1();
		} catch (Exception e) {
			e.printStackTrace();

		}
	}

	// ��������
	public void handlerBtnB_deleteAction(ActionEvent event) {
		BooksDAO bDao = new BooksDAO();
		BooksVO bVo = new BooksVO();

		try {
			btnB_delete.setDisable(false);
			bDao.getBooksB_delete(selectBook.get(0).getB_num());
			data.removeAll(data);

			totalList();

		} catch (Exception e) {

		}
	}

	// ���� ���� �ҽ�
	public void sendEmail() {
		try {

			MembersVO mvo = new MembersVO();
			MembersDAO mdao = new MembersDAO();
			InfoVO ivo = new InfoVO();
			InfoDAO idao = new InfoDAO();
			ArrayList<Integer> list = idao.late();
			int rowCount = list.size();
			String name = null;
			String em = null;

			for (int index = 0; index < rowCount; index++) {
				name = mdao.getMembersName(list.get(index));
				em = mdao.getMembersEmail(list.get(index));
				String rt = "����";
				MultiPartEmail email = new MultiPartEmail();
				email.setHostName("smtp.gmail.com");
				email.setSmtpPort(587);
				email.setAuthentication("kkyid1", "1m4e27a256n");
				email.setSSL(true);
				email.setTLS(true);
				email.addTo(em, name, "utf-8");
				email.setFrom("slicaos@naver.com", "����", "utf-8");
				email.setSubject("��뵵�������� �˷��帳�ϴ�.");
				email.setMsg("�����ݳ��� ��ü�Ǿ����ϴ�. �����ݳ� ��Ź�帳�ϴ�.");
				rt = email.send();
			}

		} catch (Exception e) {
			e.printStackTrace();
		}

	}
}
