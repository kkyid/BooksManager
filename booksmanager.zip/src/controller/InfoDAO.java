package controller;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.util.ArrayList;

import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import model.BooksVO;
import model.InfoVO;

public class InfoDAO {
	// �뿩��ȸ ���
	public InfoVO getInfoRegiste(InfoVO ivo) throws Exception {

		// ������ ó���� ���� SQL��
		String dml = "insert into info" + "(i_num, b_num, mnum, loanDate, returnDate, b_name)" + "values"
				+ "(info_seq.nextval, ?, ?, sysdate, sysdate+14, ?)";
		Connection con = null;
		PreparedStatement pstmt = null;
		InfoVO retval = null;

		try {
			// DBUtil �̶�� Ŭ������ getConnection() �޼ҵ�� ������ ���̽��� ����
			con = DBUtil.getConnection();

			// �Է¹��� �л� ������ ó���ϱ� ���Ͽ� SQL�������
			pstmt = con.prepareStatement(dml);
			pstmt.setInt(1, ivo.getB_num());
			pstmt.setInt(2, ivo.getMnum());
			pstmt.setString(3, ivo.getB_name());
			// SQL���� ���� �� ó�� ����� ����
			int i = pstmt.executeUpdate();
			retval = new InfoVO();
		} catch (SQLException e) {
			System.out.println("��");
		} catch (Exception e) {
			System.out.println("������");
		} finally {
			try {
				// �����ͺ��̽����� ���ῡ ���Ǿ��� ������Ʈ�� ����
				if (pstmt != null)
					pstmt.close();
				if (con != null)
					con.close();
			} catch (SQLException e) {
				System.out.println("�ִ�");
			}
		}
		return retval;
	}

	// �뿩 ��ü ����Ʈ
	public ArrayList<InfoVO> getInfoTotal() {
		ArrayList<InfoVO> list = new ArrayList<InfoVO>();
		String tml = "select * from Info";
		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		InfoVO iVo = null;
		try {
			con = DBUtil.getConnection();
			pstmt = con.prepareStatement(tml);
			rs = pstmt.executeQuery();
			while (rs.next()) {
				iVo = new InfoVO(rs.getInt(1), rs.getInt(2), rs.getInt(3), rs.getDate(4) + "", rs.getDate(5) + "",
						rs.getString(6));
				list.add(iVo);
			}
		} catch (SQLException se) {
			System.out.println(se);
		} catch (Exception e) {
			System.out.println(e);
		} finally {
			try {
				if (rs != null)
					rs.close();
				if (pstmt != null)
					pstmt.close();
				if (con != null)
					con.close();
			} catch (SQLException se) {

			}
		}
		return list;
	}

	// �����ͺ��̽����� ��ȸ ���̺��� �÷��� ����
	public ArrayList<String> getColumnName() {
		ArrayList<String> columnName = new ArrayList<String>();

		String sql = "select * from info";
		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		// ResultSetMetaData ��ü ���� ����
		ResultSetMetaData rsmd = null;

		try {
			con = DBUtil.getConnection();
			pstmt = con.prepareStatement(sql);
			rs = pstmt.executeQuery();
			rsmd = rs.getMetaData();
			int cols = rsmd.getColumnCount();
			for (int i = 1; i <= cols; i++) {
				columnName.add(rsmd.getColumnName(i));
			}

		} catch (SQLException se) {
			System.out.println(se);
		} catch (Exception e) {
			System.out.println(e);
		} finally {
			try {
				if (rs != null)
					rs.close();
				if (pstmt != null)
					pstmt.close();
				if (con != null)
					con.close();
			} catch (SQLException se) {

			}
		}
		return columnName;
	}

	// �뿩 ����
	public void getInfoDelete(int no) {
		StringBuffer sql = new StringBuffer();
		sql.append("delete from info where b_num = ?");
		Connection con = null;
		PreparedStatement pstmt = null;
		try {
			con = DBUtil.getConnection();
			pstmt = con.prepareStatement(sql.toString());
			pstmt.setInt(1, no);

			int i = pstmt.executeUpdate();

		

		} catch (Exception ex) {
			System.out.println(ex);
		} finally {
			try {
				if (pstmt != null)
					pstmt.close();
				if (con != null)
					con.close();
			} catch (Exception e) {
				System.out.println(e);
			}
		}

	}

	// �ش� ȸ����ȣ�� �뿩���� ��ȸ
	public ArrayList<InfoVO> loanBooksCheck(int no) {
		StringBuffer sql = new StringBuffer();
		sql.append("select * from info where mnum = ?");
		Connection con = null;
		PreparedStatement pstmt = null;
		ArrayList<InfoVO> list = new ArrayList<>();
		InfoVO iv;
		ResultSet rs = null;
		BooksController bc = new BooksController();
		try {
			con = DBUtil.getConnection();
			pstmt = con.prepareStatement(sql.toString());
			pstmt.setInt(1, no);

			rs = pstmt.executeQuery();
			while (rs.next()) {
				iv = new InfoVO(rs.getInt(1), rs.getInt(2), rs.getInt(3), rs.getDate(4) + "", rs.getDate(5) + "",
						rs.getString(6));
				list.add(iv);
			}
		} catch (Exception ex) {
			ex.printStackTrace();
		} finally {
			try {
				if (rs != null)
					rs.close();
				if (pstmt != null)
					pstmt.close();
				if (con != null)
					con.close();
			} catch (Exception ex) {
				System.out.println("2");
			}
		}
		return list;

	}

	// �ִ�뿩�� ����
	public int limit(int no) throws Exception {
		StringBuffer sql = new StringBuffer();
		sql.append("select count(*) as kim from info where mnum = ?");

		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		InfoVO ivo = new InfoVO();
		int limit = 0;

		try {
			con = DBUtil.getConnection();
			pstmt = con.prepareStatement(sql.toString());
			pstmt.setInt(1, no);
			rs = pstmt.executeQuery();
			if (rs.next()) {
				ivo.setLimit(rs.getInt(1));
			}
			limit = ivo.getLimit();

		} catch (SQLException e) {

			e.printStackTrace();
		} catch (Exception e) {
		} finally {
			try { // �����ͺ��̽����� ���ῡ ���Ǿ��� ������Ʈ�� ���� if (pstmt != null)
				pstmt.close();
				if (con != null)
					con.close();
			} catch (SQLException e) {
			}
		}
		return limit;
	}

	// ��ü ȸ�� ȸ����ȣ�̱�
	public ArrayList<Integer> late() {
		StringBuffer sql = new StringBuffer();
		sql.append("select mnum from info where not(returndate>sysdate)");
		Connection con = null;
	
		PreparedStatement pstmt = null;
		ArrayList<Integer> list = new ArrayList<>();
		int info;
		ResultSet rs = null;

		try {
			con = DBUtil.getConnection();
			pstmt = con.prepareStatement(sql.toString());
			rs = pstmt.executeQuery();
			while (rs.next()) {
				info = rs.getInt(1);
				list.add(info);
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if (rs != null)
					rs.close();
				if (pstmt != null)
					pstmt.close();
				if (con != null)
					con.close();
			} catch (Exception ex) {
				System.out.println(ex);
			}
		}
		return list;
	}

}
