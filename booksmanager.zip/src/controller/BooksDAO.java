package controller;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.util.ArrayList;

import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import model.BooksVO;

public class BooksDAO {

	// �ҿ����ϴϱ� �������� �� ����

	// �űԵ��� ���
	public BooksVO getBooksregiste(BooksVO bvo) throws Exception {

		// ������ ó���� ���� SQL��
		String dml = "insert into books"
				+ "(b_num, b_name, b_datatype, b_group, b_authormatter, b_publicationmatter, b_ISBN, b_registernum, b_loanSituation)"
				+ "values" + "(books_seq.nextval, ?, ?, ?, ?, ?, ?, ?, ?)";
		Connection con = null;
		PreparedStatement pstmt = null;
		BooksVO retval = null;

		try {
			// DBUtil �̶�� Ŭ������ getConnection() �޼ҵ�� ������ ���̽��� ����
			con = DBUtil.getConnection();

			// �Է¹��� �л� ������ ó���ϱ� ���Ͽ� SQL�������
			pstmt = con.prepareStatement(dml);
			pstmt.setString(1, bvo.getB_name());
			pstmt.setString(2, bvo.getB_datatype());
			pstmt.setString(3, bvo.getB_group());
			pstmt.setString(4, bvo.getB_authormatter());
			pstmt.setString(5, bvo.getB_publicationmatter());
			pstmt.setString(6, bvo.getB_isbn());
			pstmt.setString(7, bvo.getB_registernum());
			pstmt.setString(8, bvo.getB_loansituation());

			// SQL���� ���� �� ó�� ����� ����
			int i = pstmt.executeUpdate();
			retval = new BooksVO();
		} catch (SQLException e) {
			System.out.println("d");
		} catch (Exception e) {
			System.out.println("f");
		} finally {
			try {
				// �����ͺ��̽����� ���ῡ ���Ǿ��� ������Ʈ�� ����
				if (pstmt != null)
					pstmt.close();
				if (con != null)
					con.close();
			} catch (SQLException e) {

			}
		}
		return retval;
	}

	// ������ name�� �Է¹޾� ���� ��ȸ
	public BooksVO getBooksCheck(String b_name) throws Exception {
		String dml = "select * from books where b_name = ?";

		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		BooksVO retval = null;
		try {
			con = DBUtil.getConnection();
			pstmt = con.prepareStatement(dml);
			pstmt.setString(1, b_name);
			rs = pstmt.executeQuery();
			if (rs.next()) {
				retval = new BooksVO(rs.getInt(1), rs.getString(2), rs.getString(3), rs.getString(4), rs.getString(5),
						rs.getString(6), rs.getString(7), rs.getString(8), rs.getString(9));
			}
		} catch (SQLException se) {
			System.out.println(se);
		} catch (Exception e) {
			System.out.println(e);
		} finally {
			try {
				if (rs != null)
					rs.close();
				if (pstmt != null)
					pstmt.close();
				if (con != null)
					con.close();

			} catch (SQLException se) {

			}
		}
		return retval;
	}

	// ������ num�� �Է¹޾� ���� ��ȸ
	public BooksVO getBooksCheck1(String b_num) throws Exception {
		String dml = "select * from books where b_num = ?";

		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		BooksVO retval = null;
		try {
			con = DBUtil.getConnection();
			pstmt = con.prepareStatement(dml);
			pstmt.setString(1, b_num);
			rs = pstmt.executeQuery();
			if (rs.next()) {
				retval = new BooksVO(rs.getInt(1), rs.getString(2), rs.getString(3), rs.getString(4), rs.getString(5),
						rs.getString(6), rs.getString(7), rs.getString(8), rs.getString(9));

			}
		} catch (SQLException se) {
			System.out.println(se);
		} catch (Exception e) {
			System.out.println(e);
		} finally {
			try {
				if (rs != null)
					rs.close();
				if (pstmt != null)
					pstmt.close();
				if (con != null)
					con.close();

			} catch (SQLException se) {

			}
		}
		return retval;
	}

	// ��������
	public void getBooksB_delete(int b_num) {
		StringBuffer sql = new StringBuffer();
		sql.append("delete from books where b_num = ?");
		Connection con = null;
		PreparedStatement pstmt = null;

		try {
			con = DBUtil.getConnection();
			pstmt = con.prepareStatement(sql.toString());
			pstmt.setInt(1, b_num);
			int i = pstmt.executeUpdate();

			if (i == 1) {
				Alert alert = new Alert(AlertType.INFORMATION);
				alert.setTitle("���� ����");
				alert.setHeaderText("���� ���� �Ϸ�.");
				alert.setContentText("���� ���� ����!!!");
				alert.showAndWait();
			} else {
				Alert alert = new Alert(AlertType.INFORMATION);
				alert.setTitle("���� ����");
				alert.setHeaderText("���� ���� ����.");
				alert.setContentText("���� ���� ����!!!");
				alert.showAndWait();
			}

		} catch (Exception ex) {
			System.out.println(ex);
		} finally {
			try {
				if (pstmt != null)
					pstmt.close();
				if (con != null)
					con.close();
			} catch (Exception e) {
				System.out.println(e);
			}
		}

	}

	// ���� ��ü ����Ʈ
	public ArrayList<BooksVO> getBooksTotal() {
		ArrayList<BooksVO> list = new ArrayList<BooksVO>();
		String tml = "select * from Books";

		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		BooksVO emVo = null;

		try {
			con = DBUtil.getConnection();
			pstmt = con.prepareStatement(tml);
			rs = pstmt.executeQuery();
			while (rs.next()) {
				emVo = new BooksVO(rs.getInt(1), rs.getString(2), rs.getString(3), rs.getString(4), rs.getString(5),
						rs.getString(6), rs.getString(7), rs.getString(8), rs.getString(9));
				list.add(emVo);
			}
		} catch (SQLException se) {
			System.out.println(se);
		} catch (Exception e) {
			System.out.println(e);
		} finally {
			try {
				if (rs != null)
					rs.close();
				if (pstmt != null)
					pstmt.close();
				if (con != null)
					con.close();
			} catch (SQLException se) {
			}
		}
		return list;
	}

	// �����ͺ��̽����� �л� ���̺��� �÷��� ����
	public ArrayList<String> getColumnName() {
		ArrayList<String> columnName = new ArrayList<String>();

		String sql = "select * from books";
		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		// ResultSetMetaData ��ü ���� ����
		ResultSetMetaData rsmd = null;

		try {
			con = DBUtil.getConnection();
			pstmt = con.prepareStatement(sql);
			rs = pstmt.executeQuery();
			rsmd = rs.getMetaData();
			int cols = rsmd.getColumnCount();
			for (int i = 1; i <= cols; i++) {
				columnName.add(rsmd.getColumnName(i));
			}

		} catch (SQLException se) {
			System.out.println(se);
		} catch (Exception e) {
			System.out.println(e);
		} finally {
			try {
				if (rs != null)
					rs.close();
				if (pstmt != null)
					pstmt.close();
				if (con != null)
					con.close();
			} catch (SQLException se) {

			}
		}
		return columnName;
	}

	// �������� ������Ʈ
	public BooksVO getBooksReser(BooksVO bvo, int B_num) throws Exception {
		String dml = "update books set " + "B_loansituation= where B_num= ?";
		Connection con = null;
		PreparedStatement pstmt = null;
		BooksVO retval = null;

		try {
			// DBUtil�̶�� Ŭ������ getConnection()�޼ҵ�� �����ͺ��̽��� ����
			con = DBUtil.getConnection();

			// ������ �л� ������ �����ϱ� ���Ͽ� SQL������ ����

			pstmt = con.prepareStatement(dml);
			pstmt.setString(1, bvo.getB_loansituation());
			pstmt.setInt(2, B_num);

			// SQL���� ������ �� ó�� ����� ����
			int i = pstmt.executeUpdate();

			if (i == 1) {
				Alert alert = new Alert(AlertType.INFORMATION);
				alert.setTitle("���� ���");
				alert.setContentText("���༺��!!");
				alert.showAndWait();
				retval = new BooksVO();

			} else {
				Alert alert = new Alert(AlertType.INFORMATION);
				alert.setTitle("���� ���");
				alert.setContentText("�������!!");
				alert.showAndWait();
			}
		} catch (SQLException e) {
		} catch (Exception e) {
		} finally {
			try {
				// �����ͺ��̽����� ���ῡ ���Ǿ��� ������Ʈ�� ����
				if (pstmt != null)
					pstmt.close();
				if (con != null)
					con.close();
			} catch (SQLException e) {

			}
		}
		return retval;

	}

	// ������ ���� ����
	public BooksVO getBooksUpdate(BooksVO bvo, int B_num) throws Exception {
		// ������ ó���� ���� SQL��
		String dml = "update books set "
				+ " B_name=?, B_datatype=?, B_group=?, B_authormatter=?, B_publicationmatter=?, B_isbn=?, B_registerNum=?, B_loansituation=? where B_num= ?";
		Connection con = null;
		PreparedStatement pstmt = null;
		BooksVO retval = null;

		try {
			// DBUtil�̶�� Ŭ������ getConnection()�޼ҵ�� �����ͺ��̽��� ����
			con = DBUtil.getConnection();

			// ������ �л� ������ �����ϱ� ���Ͽ� SQL������ ����

			pstmt = con.prepareStatement(dml);
			pstmt.setString(1, bvo.getB_name());
			pstmt.setString(2, bvo.getB_datatype());
			pstmt.setString(3, bvo.getB_group());
			pstmt.setString(4, bvo.getB_authormatter());
			pstmt.setString(5, bvo.getB_publicationmatter());
			pstmt.setString(6, bvo.getB_isbn());
			pstmt.setString(7, bvo.getB_registernum());
			pstmt.setString(8, bvo.getB_loansituation());
			pstmt.setInt(9, B_num);

			// SQL���� ������ �� ó�� ����� ����
			int i = pstmt.executeUpdate();
			if (i == 1) {
				Alert alert = new Alert(AlertType.INFORMATION);
				alert.setTitle("���� ���");
				alert.setContentText("��������!!");
				alert.showAndWait();
				retval = new BooksVO();

			} else {
				Alert alert = new Alert(AlertType.INFORMATION);
				alert.setTitle("���� ���");
				alert.setContentText("��������!!");
				alert.showAndWait();
			}
		} catch (SQLException e) {
			System.out.println("d");
		} catch (Exception e) {
			System.out.println("s");
		} finally {
			try {
				// �����ͺ��̽����� ���ῡ ���Ǿ��� ������Ʈ�� ����
				if (pstmt != null)
					pstmt.close();
				if (con != null)
					con.close();
			} catch (SQLException e) {
			}
		}
		return retval;

	}

	public ArrayList<BooksVO> loansituation() {
		StringBuffer sql = new StringBuffer();
		sql.append("select * from books where b_loansituation is not null");
		Connection con = null;
		PreparedStatement pstmt = null;
		ArrayList<BooksVO> list = new ArrayList<>();
		BooksVO bk;
		ResultSet rs = null;

		try {
			con = DBUtil.getConnection();
			pstmt = con.prepareStatement(sql.toString());
			rs = pstmt.executeQuery();
			while (rs.next()) {
				bk = new BooksVO(rs.getInt(1), rs.getString(2), rs.getString(3), rs.getString(4), rs.getString(5),
						rs.getString(6), rs.getString(7), rs.getString(8), rs.getString(9));
				list.add(bk);
			}
		} catch (Exception ex) {
			System.out.println(ex);
		} finally {
			try {
				if (rs != null)
					rs.close();
				if (pstmt != null)
					pstmt.close();
				if (con != null)
					con.close();
			} catch (Exception ex) {
				System.out.println(ex);
			}
		}
		return list;
	}

	public ArrayList<BooksVO> keepList() {
		StringBuffer sql = new StringBuffer();
		sql.append("select * from books where b_loansituation is null");
		Connection con = null;
		PreparedStatement pstmt = null;
		ArrayList<BooksVO> list = new ArrayList<>();
		BooksVO bk;
		ResultSet rs = null;
		try {
			con = DBUtil.getConnection();
			pstmt = con.prepareStatement(sql.toString());
			rs = pstmt.executeQuery();
			while (rs.next()) {
				bk = new BooksVO(rs.getInt(1), rs.getString(2), rs.getString(3), rs.getString(4), rs.getString(5),
						rs.getString(6), rs.getString(7), rs.getString(8), rs.getString(9));
				list.add(bk);
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if (rs != null)
					rs.close();
				if (pstmt != null)
					pstmt.close();
				if (con != null)
					con.close();
			} catch (Exception e) {

				e.printStackTrace();
			}
		}
		return list;
	}

	public ArrayList<BooksVO> loanList() {
		StringBuffer sql = new StringBuffer();
		sql.append("select * from books where b_loansituation is not null");
		Connection con = null;
		PreparedStatement pstmt = null;
		ArrayList<BooksVO> list = new ArrayList<>();
		BooksVO bk;
		ResultSet rs = null;
		try {
			con = DBUtil.getConnection();
			pstmt = con.prepareStatement(sql.toString());

			rs = pstmt.executeQuery();
			while (rs.next()) {
				bk = new BooksVO(rs.getInt(1), rs.getString(2), rs.getString(3), rs.getString(4), rs.getString(5),
						rs.getString(6), rs.getString(7), rs.getString(8), rs.getString(9));
				list.add(bk);
			}
		} catch (Exception ex) {
			System.out.println(ex);
		} finally {
			try {
				if (rs != null)
					rs.close();
				if (pstmt != null)
					pstmt.close();
				if (con != null)
					con.close();
			} catch (Exception ex) {
				System.out.println(ex);
			}
		}
		return list;

	}

	public void loanUpdate(String loan, int no) {
		StringBuffer sql = new StringBuffer();
		sql.append("update books set");
		sql.append("  b_loansituation = ?");
		sql.append(" where b_num = ?");
		Connection con = null;
		PreparedStatement pstmt = null;
		try {
			con = DBUtil.getConnection();
			pstmt = con.prepareStatement(sql.toString());
			pstmt.setString(1, loan);
			pstmt.setInt(2, no);
			int i = pstmt.executeUpdate();
			if (i == 1) {
			}
		} catch (Exception ex) {
			System.out.println(ex);
		} finally {
			try {
				if (pstmt != null)
					pstmt.close();
				if (con != null)
					con.close();
			} catch (Exception ex) {
				System.out.println(ex);
			}
		}
	}

	public ArrayList<BooksVO> loansituationnull() {
		StringBuffer sql = new StringBuffer();
		sql.append("select * from books where b_loansituation is null");
		Connection con = null;
		PreparedStatement pstmt = null;
		ArrayList<BooksVO> list = new ArrayList<>();
		BooksVO bk;
		ResultSet rs = null;

		try {
			con = DBUtil.getConnection();
			pstmt = con.prepareStatement(sql.toString());
			rs = pstmt.executeQuery();
			while (rs.next()) {
				bk = new BooksVO(rs.getInt(1), rs.getString(2), rs.getString(3), rs.getString(4), rs.getString(5),
						rs.getString(6), rs.getString(7), rs.getString(8), rs.getString(9));
				list.add(bk);
			}
		} catch (Exception ex) {
			System.out.println(ex);
		} finally {
			try {
				if (rs != null)
					rs.close();
				if (pstmt != null)
					pstmt.close();
				if (con != null)
					con.close();
			} catch (Exception ex) {
				System.out.println(ex);
			}
		}
		return list;

	}

}
