package model;

public class BooksVO {

	private int b_num;
	private String b_name;
	private String b_datatype;
	private String b_group;
	private String b_authormatter;
	private String b_publicationmatter;
	private String b_isbn;
	private String b_registernum;
	private String b_loansituation;

	public BooksVO() {
		super();
	}

	public BooksVO(int b_num, String b_name, String b_datatype, String b_group, String b_authormatter,
			String b_publicationmatter, String b_isbn, String b_registernum, String b_loansituation) {
		super();
		this.b_num = b_num;
		this.b_name = b_name;
		this.b_datatype = b_datatype;
		this.b_group = b_group;
		this.b_authormatter = b_authormatter;
		this.b_publicationmatter = b_publicationmatter;
		this.b_isbn = b_isbn;
		this.b_registernum = b_registernum;
		this.b_loansituation = b_loansituation;
	}

	public BooksVO(String b_name, String b_datatype, String b_group, String b_authormatter, String b_publicationmatter,
			String b_isbn, String b_registernum, String b_loansituation) {
		super();
		this.b_name = b_name;
		this.b_datatype = b_datatype;
		this.b_group = b_group;
		this.b_authormatter = b_authormatter;
		this.b_publicationmatter = b_publicationmatter;
		this.b_isbn = b_isbn;
		this.b_registernum = b_registernum;
		this.b_loansituation = b_loansituation;
	}

	public BooksVO(String b_name, String b_datatype, String b_group, String b_authormatter, String b_publicationmatter,
			String b_isbn, String b_registernum) {
		super();
		this.b_name = b_name;
		this.b_datatype = b_datatype;
		this.b_group = b_group;
		this.b_authormatter = b_authormatter;
		this.b_publicationmatter = b_publicationmatter;
		this.b_isbn = b_isbn;
		this.b_registernum = b_registernum;
	}

	public int getB_num() {
		return b_num;
	}

	public void setB_num(int b_num) {
		this.b_num = b_num;
	}

	public String getB_name() {
		return b_name;
	}

	public void setB_name(String b_name) {
		this.b_name = b_name;
	}

	public String getB_datatype() {
		return b_datatype;
	}

	public void setB_datatype(String b_datatype) {
		this.b_datatype = b_datatype;
	}

	public String getB_group() {
		return b_group;
	}

	public void setB_group(String b_group) {
		this.b_group = b_group;
	}

	public String getB_authormatter() {
		return b_authormatter;
	}

	public void setB_authormatter(String b_authormatter) {
		this.b_authormatter = b_authormatter;
	}

	public String getB_publicationmatter() {
		return b_publicationmatter;
	}

	public void setB_publicationmatter(String b_publicationmatter) {
		this.b_publicationmatter = b_publicationmatter;
	}

	public String getB_isbn() {
		return b_isbn;
	}

	public void setB_isbn(String b_isbn) {
		this.b_isbn = b_isbn;
	}

	public String getB_registernum() {
		return b_registernum;
	}

	public void setB_registernum(String b_registernum) {
		this.b_registernum = b_registernum;
	}

	public String getB_loansituation() {
		return b_loansituation;
	}

	public void setB_loansituation(String b_loansituation) {
		this.b_loansituation = b_loansituation;
	}

	
}
