package model;

import java.sql.Date;

public class MembersVO {

	private int mnum;
	private String name;
	private int birth;
	private String phone;
	private String gender;
	private String email;
	private String address;
	private String registerDate;
	private String note;

	public MembersVO() {
		super();
	}

	public MembersVO(int mnum, String name, int birth, String phone, String gender, String email, String address,
			String registerDate, String note) {
		super();
		this.mnum = mnum;
		this.name = name;
		this.birth = birth;
		this.phone = phone;
		this.gender = gender;
		this.email = email;
		this.address = address;
		this.registerDate = registerDate;
		this.note = note;
	}

	public MembersVO(int mnum, String name, int birth, String phone, String email, String address, String registerDate,
			String note) {
		super();
		this.mnum = mnum;
		this.name = name;
		this.birth = birth;
		this.phone = phone;
		this.email = email;
		this.address = address;
		this.registerDate = registerDate;
		this.note = note;
	}

	public MembersVO(String name, int birth, String phone, String gender, String email, String address,
			String registerDate, String note) {
		super();
		this.name = name;
		this.birth = birth;
		this.phone = phone;
		this.gender = gender;
		this.email = email;
		this.address = address;
		this.registerDate = registerDate;
		this.note = note;
	}

	public MembersVO(String name, int birth, String phone, String email, String address, String registerDate) {
		super();
		this.name = name;
		this.birth = birth;
		this.phone = phone;
		this.email = email;
		this.address = address;
		this.registerDate = registerDate;
	}

	public int getMnum() {
		return mnum;
	}

	public void setMnum(int mnum) {
		this.mnum = mnum;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getBirth() {
		return birth;
	}

	public void setBirth(int birth) {
		this.birth = birth;
	}

	public String getPhone() {
		return phone;
	}

	public void setPhone(String phone) {
		this.phone = phone;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getRegisterDate() {
		return registerDate;
	}

	public void setRegisterDate(String registerDate) {
		this.registerDate = registerDate;
	}

	public String getNote() {
		return note;
	}

	public void setNote(String note) {
		this.note = note;
	}

}
