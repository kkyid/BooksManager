package model;

public class InfoVO {

	private int i_num;
	private int b_num;
	private int mnum;
	private String loanDate;
	private String returnDate;
	private String b_name;
	private int limit;

	public InfoVO() {
		super();
	}

	
	
	
	public InfoVO(int i_num, int b_num, int mnum, String loanDate, String returnDate, String b_name, int limit) {
		super();
		this.i_num = i_num;
		this.b_num = b_num;
		this.mnum = mnum;
		this.loanDate = loanDate;
		this.returnDate = returnDate;
		this.b_name = b_name;
		this.limit = limit;
	}



	public InfoVO(int limit) {
		super();
		this.limit = limit;
	}

	public InfoVO(int i_num, int b_num, int mnum, String loanDate, String returnDate, String b_name) {
		super();
		this.i_num = i_num;
		this.b_num = b_num;
		this.mnum = mnum;
		this.loanDate = loanDate;
		this.returnDate = returnDate;
		this.b_name = b_name;
	}

	public InfoVO(int b_num, int mnum, String b_name) {
		super();
		this.b_num = b_num;
		this.mnum = mnum;
		this.b_name = b_name;
	}

	public int getI_num() {
		return i_num;
	}

	public void setI_num(int i_num) {
		this.i_num = i_num;
	}

	public int getB_num() {
		return b_num;
	}

	public void setB_num(int b_num) {
		this.b_num = b_num;
	}

	public int getMnum() {
		return mnum;
	}

	public void setMnum(int mnum) {
		this.mnum = mnum;
	}

	public String getLoanDate() {
		return loanDate;
	}

	public void setLoanDate(String loanDate) {
		this.loanDate = loanDate;
	}

	public String getReturnDate() {
		return returnDate;
	}

	public void setReturnDate(String returnDate) {
		this.returnDate = returnDate;
	}

	public String getB_name() {
		return b_name;
	}

	public void setB_name(String b_name) {
		this.b_name = b_name;
	}

	public int getLimit() {
		return limit;
	}

	public void setLimit(int limit) {
		this.limit = limit;
	}

}